# Agentic workflows in Codex

A fictional workshop page gives us one job to try several ways. The prompts use ordinary language. You do not need to type a Python command or memorize file paths.

## Start here

1. Extract this ZIP and open **workshop-launch** as a project in Codex.
2. Read the approved event details and writing guide in that folder.
3. Open a prompt from **prompts**, copy it, and send it in a fresh chat.
4. Inspect the new draft and any review findings.
5. Compare with the matching result under **examples**.

Use a fresh copy of workshop-launch for each run so an earlier revision does not replace the starting conditions. Codex can locate the files and run the prepared checks. Those checks catch specific planted mistakes; they do not replace reading the sources and reviewing the prose.

## Pick a workflow

- **sequence**: one agent improves the page and checks the result
- **routing**: the saved review skill helps inspect the page
- **parallel**: two independent reviewers return findings
- **manager**: two reviewers finish before a separate writer starts
- **bounded**: review and fix, with a maximum of two passes
- **missing**: draft what is supported and flag unknown seat availability

## More than one good answer

For a short rewrite, compare **practice-1-simple** with **practice-1-review**. One agent may be enough. A separate reviewer gives another perspective when it is useful.

For a launch pack, compare **practice-2-simple** with **practice-2-team**. One agent can create all three drafts, or three agents can own different outputs. Either way, someone must compare the final facts.

All ten prompts were executed in isolated copies of this exercise. The examples record those runs, not a promise that your wording will be identical. Native subagents depend on your available Codex client and account. If a feature is unavailable, work through the steps with one agent and inspect the recorded team example.

The hidden review skill and check script are included. Technical setup details are in the workshop folder's README for Codex to read. The check script requires Python 3 on the host; learners can still follow the results and write prompts without running it.

Nothing here authorizes sending or publishing. All event facts are fictional, including the fixed exercise date.

# Recorded Codex workflow

One observed run: 44.0 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:05 | read skill: review instructions |
| 00:13 | spawn: facts_review |
| 00:18 | spawn: writing_review |
| 00:25 | returned: /root/facts_review |
| 00:34 | returned: /root/writing_review |
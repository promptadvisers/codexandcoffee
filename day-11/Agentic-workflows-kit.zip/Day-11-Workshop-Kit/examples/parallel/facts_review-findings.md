Factual review of `drafts/workshop-page.md` against `approved-event.md`:

| Page passage | Approved evidence | Smallest useful fix |
|---|---|---|
| “11 February 2027” | “Date: 18 February 2027” | Replace with “18 February 2027”. |
| “in-person workshop” | “Format: live online” | Replace with “live online workshop”. |
| “costs $79” | “Price: $49” | Replace with “costs $49”. |
| “guarantee double productivity” | “There is no evidence for productivity guarantees.” | Remove the guarantee; replace the sentence with “Practice preparing documents and reports using AI.” |
| “Only 12 seats remain!” | “Current seat availability is not provided.” | Delete the sentence. Availability is unknown; do not substitute another count. |

The heading “Unlock unprecedented productivity” also implies an unsupported benefit, although its principal issue is hype under the writing guide. Suggested replacement: “Useful AI at Work”.

Correct claims: workshop name, time (14:00–15:00 UTC), document/report practice, no coding prerequisite, seven-day recording availability, and registration URL all match the approved details. The practice sentence would be more precise if it explicitly included “using AI”. The approved audience (“people who prepare documents and reports”) is not expressly stated, but that is an omission rather than a false claim.

No files changed.
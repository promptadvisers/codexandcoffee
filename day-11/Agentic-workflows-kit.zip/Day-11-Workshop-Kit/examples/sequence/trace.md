# Recorded Codex workflow

One observed run: 21.0 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:05 | read skill: review instructions |
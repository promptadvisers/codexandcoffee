Saved the [revised workshop page](output/workshop-page.md). The original is unchanged.

- Corrected the date, price, and format to the approved details.
- Replaced hype, the productivity guarantee, and invented seat scarcity with plain language about what participants will practice.
- Retained the prerequisite, recording availability, and registration link.

All **9 prepared checks passed**. I also compared the revision against the approved facts and writing guide.

Nothing remains unresolved for this exercise. Nothing was published.
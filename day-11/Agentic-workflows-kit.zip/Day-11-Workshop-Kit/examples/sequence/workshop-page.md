# Useful AI at Work: preparing documents and reports

Useful AI at Work is a live online workshop for people who prepare documents and reports. You’ll practice preparing these materials using AI. No coding experience is required.

The workshop takes place on 18 February 2027, from 14:00–15:00 UTC. The price is $49.

The recording will be available for seven days.

[Register for Useful AI at Work](https://example.com/workshop).

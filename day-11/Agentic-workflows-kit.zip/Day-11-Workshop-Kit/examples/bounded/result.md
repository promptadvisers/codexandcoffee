Saved the [corrected page](output/workshop-page.md).

Factual fixes:
- “11 February,” “in-person,” and “$79” → approved details: 18 February 2027, live online, $49.
- “Only 12 seats remain!” → removed; availability is unknown.

Writing fixes:
- “Unlock unprecedented productivity” → descriptive heading.
- “Leverage cutting-edge synergies to guarantee double productivity” → practical description of using AI for documents and reports, as the guide requires.

All 9 prepared checks passed on the first pass. Source comparison found no remaining issues. The original is unchanged; nothing was published.
# Useful AI at Work: preparing documents and reports

Join Useful AI at Work, a live online workshop for people who prepare documents and reports.

The workshop takes place on 18 February 2027, 14:00–15:00 UTC. The price is $49.

You’ll practice preparing documents and reports using AI. No coding experience is required.

The recording is available for seven days.

Register: https://example.com/workshop

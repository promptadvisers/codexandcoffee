# Recorded Codex workflow

One observed run: 20.9 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:04 | read skill: review instructions |
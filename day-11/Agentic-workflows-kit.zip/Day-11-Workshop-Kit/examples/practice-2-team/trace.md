# Recorded Codex workflow

One observed run: 56.2 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:07 | read skill: review instructions |
| 00:10 | read skill: review instructions |
| 00:17 | spawn: event_page |
| 00:21 | spawn: email_draft |
| 00:25 | spawn: social_posts |
| 00:30 | returned: /root/event_page |
| 00:35 | returned: /root/email_draft |
| 00:49 | returned: /root/social_posts |
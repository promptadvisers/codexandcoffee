# Useful AI at Work: practice preparing documents and reports

Prepare documents or reports for work? Join Useful AI at Work, a live online workshop where you’ll practice preparing documents and reports using AI. No coding experience is required.

- **Date:** 18 February 2027
- **Time:** 14:00–15:00 UTC
- **Format:** Live online
- **Price:** $49

A recording will be available for seven days.

[Register for Useful AI at Work](https://example.com/workshop).

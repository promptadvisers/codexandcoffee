# Social posts: Useful AI at Work

## Post 1: Practice with documents and reports

Prepare documents and reports at work? Useful AI at Work is a live online workshop where you’ll practice preparing them using AI.

18 February 2027, 14:00–15:00 UTC. $49. No coding experience required. A recording will be available for seven days.

Register: https://example.com/workshop

## Post 2: No coding experience required

You don’t need coding experience to take part in Useful AI at Work. This live online workshop is for people who prepare documents and reports, with practice using AI for those tasks.

Join on 18 February 2027, 14:00–15:00 UTC. The price is $49, and a recording will be available for seven days.

Register: https://example.com/workshop

## Post 3: Live practice, with a recording

Useful AI at Work includes live online practice preparing documents and reports using AI. A recording will be available for seven days.

The workshop is for people who prepare documents and reports. No coding experience required.

18 February 2027, 14:00–15:00 UTC. $49.

Register: https://example.com/workshop

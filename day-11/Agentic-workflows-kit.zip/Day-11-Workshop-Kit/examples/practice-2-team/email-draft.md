# Email draft: Useful AI at Work

Subject: Useful AI at Work — online workshop on 18 February

Hello,

If you prepare documents and reports, Useful AI at Work is a live online workshop where you’ll practice preparing them using AI. No coding experience is required.

The workshop takes place on 18 February 2027, from 14:00–15:00 UTC. The price is $49, and a recording will be available for seven days.

You can register here: https://example.com/workshop

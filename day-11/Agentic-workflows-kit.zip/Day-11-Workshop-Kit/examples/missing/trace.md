# Recorded Codex workflow

One observed run: 18.0 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
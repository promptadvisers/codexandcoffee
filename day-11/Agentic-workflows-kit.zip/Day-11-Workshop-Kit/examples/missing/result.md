Saved the [workshop draft](output/workshop-page.md). All 9 prepared checks passed, and I compared it with the approved facts and writing guide.

Seat availability claims are omitted because local information provides no support. Nothing was published.

Please confirm the final wording and, before publication, that the registration link works. Live booking availability remains unverified.
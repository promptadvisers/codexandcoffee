# Recorded Codex workflow

One observed run: 22.2 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:05 | read skill: review instructions |
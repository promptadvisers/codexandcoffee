The original page has three factual errors, two unsupported claims, and two writing issues. Files are unchanged.

**Factual findings**

| Page passage | Approved evidence | Suggested fix |
|---|---|---|
| “11 February 2027” | “Date: 18 February 2027” | Change to “18 February 2027.” |
| “in-person workshop” | “Format: live online” | Change to “live online workshop.” |
| “costs $79” | “Price: $49” | Change to “costs $49.” |
| “guarantee double productivity” | “There is no evidence for productivity guarantees.” | Remove the guarantee. Describe the approved practice instead: “Practice preparing documents and reports using AI.” |
| “Only 12 seats remain!” | “Current seat availability is not provided.” | Delete this sentence. Availability is unknown. |

Sources: [original page](/privatedrafts/workshop-page.md), [approved event details](/privateapproved-event.md).

**Writing findings**

| Page passage | Writing-guide evidence | Suggested fix |
|---|---|---|
| “Unlock unprecedented productivity” | “Use a clear descriptive heading”; “Avoid hype” | Use “Useful AI at Work: a live online workshop.” |
| “Leverage cutting-edge synergies” | “Use plain language”; “Explain what participants will practice.” | Replace the sentence with the concrete practice description suggested above. |

Source: [writing guide](/privatevoice-guide.md).

The time, coding prerequisite, seven-day recording access, and registration link match the approved details. The page is under 180 words.
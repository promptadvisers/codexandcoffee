Created the revised [workshop page](output/workshop-page.md) from the two reviewers’ agreed changes.

- All approved details verified.
- Prepared checks: **9/9 passed**.
- Original preserved; nothing published.
- Seat availability remains unknown and is omitted. No other unresolved issues.
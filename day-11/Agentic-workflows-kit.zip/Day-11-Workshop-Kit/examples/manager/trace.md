# Recorded Codex workflow

One observed run: 103.8 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:06 | read skill: review instructions |
| 00:14 | spawn: facts |
| 00:18 | spawn: writing |
| 00:24 | returned: /root/facts |
| 00:29 | returned: /root/facts |
| 00:33 | returned: /root/writing |
| 00:42 | returned: /root/writing |
| 00:49 | returned: /root/writing |
| 01:14 | returned: /root/facts |
| 01:21 | spawn: writer |
| 01:35 | returned: /root/writer |
# Useful AI at Work

A live online workshop for people who prepare documents and reports.

Join us on 18 February 2027, 14:00–15:00 UTC. The price is $49.

You’ll practice preparing documents and reports using AI. No coding experience is required.

The recording is available for seven days.

Register: https://example.com/workshop

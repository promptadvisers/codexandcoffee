Created `output/workshop-page.md` with all agreed changes. It is 50 words, uses plain language and short paragraphs, and preserves the approved details.

Only the new output file was written. Original files remain untouched. Nothing was published.
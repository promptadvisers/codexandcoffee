# Post 1: Workshop invitation

Prepare documents and reports at work? Join Useful AI at Work to practice using AI for those tasks. No coding experience is required.

Live online · 18 February 2027 · 14:00–15:00 UTC · $49

A recording will be available for seven days.

Register: https://example.com/workshop

# Post 2: What you’ll practice

Useful AI at Work is a live online workshop for people who prepare documents and reports. You’ll practice preparing those materials using AI, with no coding experience required.

18 February 2027 · 14:00–15:00 UTC · $49

A recording will be available for seven days.

Register: https://example.com/workshop

# Post 3: Event details

Useful AI at Work
18 February 2027 · 14:00–15:00 UTC
Live online · $49

For people who prepare documents and reports: practice using AI for that work. No coding experience is required. A recording will be available for seven days.

Register: https://example.com/workshop

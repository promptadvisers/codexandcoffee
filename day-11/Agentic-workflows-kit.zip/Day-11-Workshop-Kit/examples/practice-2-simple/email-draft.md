Subject: Useful AI at Work — live online workshop on 18 February

Hi,

If you prepare documents and reports, Useful AI at Work is a chance to practice using AI for those tasks. No coding experience is required.

The live online workshop takes place on 18 February 2027, 14:00–15:00 UTC. The price is $49, and a recording will be available for seven days.

Participants will practice preparing documents and reports using AI.

Register: https://example.com/workshop

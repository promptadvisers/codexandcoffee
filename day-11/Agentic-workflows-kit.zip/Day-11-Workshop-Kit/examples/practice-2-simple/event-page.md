# Useful AI at Work: practice preparing documents and reports

If you prepare documents and reports, this live online workshop gives you time to practice using AI for that work. No coding experience is required.

Useful AI at Work takes place on **18 February 2027, 14:00–15:00 UTC**. The price is **$49**.

Participants will practice preparing documents and reports using AI. A recording will be available for seven days.

[Register for Useful AI at Work](https://example.com/workshop).

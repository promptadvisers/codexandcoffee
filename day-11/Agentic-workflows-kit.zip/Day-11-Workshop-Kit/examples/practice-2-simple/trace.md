# Recorded Codex workflow

One observed run: 33.8 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
# Useful AI at Work: practice preparing documents and reports

This live online workshop is for people who prepare documents and reports. You’ll practice preparing documents and reports using AI. No coding experience is required.

Join us on 18 February 2027, 14:00–15:00 UTC. The workshop costs $49, and the recording is available for seven days.

[Register for Useful AI at Work](https://example.com/workshop).

# Recorded Codex workflow

One observed run: 45.0 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:09 | read skill: review instructions |
| 00:19 | spawn: review_copy |
| 00:33 | returned: /root/review_copy |
# Recorded Codex workflow

One observed run: 27.6 seconds. This is not a performance comparison.

| Elapsed | Event |
|---|---|
| 00:06 | read skill: review instructions |
| 00:12 | read skill: review instructions |
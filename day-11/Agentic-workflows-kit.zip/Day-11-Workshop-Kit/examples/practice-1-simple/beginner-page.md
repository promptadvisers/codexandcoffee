# Useful AI at Work: practice with documents and reports

Prepare documents and reports at work? In this live online workshop, you’ll practice using AI for those tasks. No coding experience is required.

Useful AI at Work takes place on 18 February 2027, from 14:00–15:00 UTC. The price is $49.

A recording will be available for seven days.

Register: https://example.com/workshop

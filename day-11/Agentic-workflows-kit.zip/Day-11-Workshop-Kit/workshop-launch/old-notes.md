# Old planning notes — superseded

Earlier proposal only. The proposed date was 11 February 2027 and the price was $79.
We considered an in-person format. Use approved-event.md for confirmed facts.

# Approved event facts

This is a fictional workshop for the class exercise. This file is the source of truth.

- Name: Useful AI at Work
- Date: 18 February 2027
- Time: 14:00–15:00 UTC
- Format: live online
- Price: $49
- Audience: people who prepare documents and reports
- Participants practice: preparing documents and reports using AI
- Prerequisite: no coding experience required
- Recording: available for seven days
- Registration link: https://example.com/workshop

Current seat availability is not provided. There is no evidence for productivity guarantees.

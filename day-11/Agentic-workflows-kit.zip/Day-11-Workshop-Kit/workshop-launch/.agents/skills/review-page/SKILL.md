---
name: review-page
description: Review a workshop page against approved event facts and a writing guide. Use when asked to audit or review a page, not when asked only to draft it.
---

# Review a workshop page

1. Read approved-event.md, voice-guide.md and the page named in the request.
2. Compare every factual claim against the approved file. Old planning notes do not override approved facts.
3. Check plain language, unsupported guarantees, pressure, and the word limit.
4. Return findings with the page passage, supporting source passage, and smallest useful fix. Keep factual and writing findings distinct.
5. Do not edit during a review. Report unknown information without guessing.

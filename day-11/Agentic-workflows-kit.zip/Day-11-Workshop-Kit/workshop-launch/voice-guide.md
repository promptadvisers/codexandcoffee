# Writing guide

Write for a busy colleague. Use plain language and short paragraphs.
Avoid hype, pressure, and guaranteed outcomes. Explain what participants will practice.
Use a clear descriptive heading. Keep the page under 180 words.
Use the approved registration link. Do not invent seat counts.

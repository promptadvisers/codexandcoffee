# Workshop folder

This is a fictional workshop. Approved event details are in approved-event.md. The writing guide is voice-guide.md. The original workshop page is drafts/workshop-page.md. Old planning notes are superseded wherever they conflict with approved details.

Save a revised page as output/workshop-page.md. For a beginner rewrite use output/beginner-page.md. For the launch pack use separate files named output/event-page.md, output/email-draft.md and output/social-posts.md. Preserve the original source files.

The prepared checks live in checks/check_page.py. To run them, use python3 checks/check_page.py followed by the path to the new page. A nine-check pass does not replace a source comparison or human review of the writing.

Our saved review-page skill is in .agents/skills/review-page/SKILL.md. Nothing in this exercise authorizes publication or sending messages.

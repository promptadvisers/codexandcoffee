from pathlib import Path
import json,re,sys
p=Path(sys.argv[1] if len(sys.argv)>1 else 'output/workshop-page.md')
s=p.read_text() if p.exists() else ''
checks={
 'file_exists':p.exists(),
 'approved_date':'18 February 2027' in s and '11 February 2027' not in s,
 'approved_price':'$49' in s and '$79' not in s,
 'online_format':'online' in s.lower() and 'in-person' not in s.lower(),
 'registration_link':'https://example.com/workshop' in s,
 'no_invented_seat_count':not bool(re.search(r'\b12\s+seats',s,re.I)),
 'no_productivity_guarantee':not bool(re.search(r'guarantee.{0,15}double|double productivity',s,re.I)),
 'under_180_words':len(s.split())<180,
 'no_hype':not any(w in s.lower() for w in ['synergies','unprecedented','cutting-edge'])
}
print(json.dumps({'file':str(p),'checks':checks,'passed':sum(checks.values()),'total':len(checks)},indent=2))
sys.exit(0 if all(checks.values()) else 1)

# Official sources

Retrieved 9 November 2026. Product behavior can change.

- [Codex best practices](https://learn.chatgpt.com/guides/best-practices): goal, context, constraints, and completion criteria
- [Codex subagents](https://learn.chatgpt.com/docs/agent-configuration/subagents): explicit requests, orchestration, custom roles, inherited permissions, and concurrency
- [Skills](https://learn.chatgpt.com/docs/build-skills): reusable workflows and discovery
- [OpenAI practical guide to building agents](https://cdn.openai.com/business-guides-and-resources/a-practical-guide-to-building-agents.pdf): single-agent baseline and manager patterns
- [Evaluation best practices](https://developers.openai.com/api/docs/guides/evaluation-best-practices): task-specific checks and testing extra complexity
- [Permissions and approvals](https://learn.chatgpt.com/docs/agent-approvals-security): instructions versus enforced access
- [Git worktrees](https://learn.chatgpt.com/docs/environments/git-worktrees): isolating independent edits

The prompts and fictional exercise are original teaching material. The native Codex runs establish the behavior of this test setup; they do not promise identical behavior across every client, configuration, or model. The examples do not establish a speed, cost, or quality advantage for using more agents.

# The original 20 patterns in current Codex


| Original chapter | Pattern | Current Codex treatment |
|---|---|---|
| 00:54 | Prompt chaining | Put dependent steps and explicit checks in one task or skill. A new chat is not required for every step. |
| 05:42 | Routing | Choose a workflow, skill, tool or specialized role based on the request. Prefer a single agent when a skill is enough. |
| 09:30 | Parallelization | Delegate independent reads to native subagents, wait and synthesize. Keep ownership explicit for writes. |
| 13:16 | Reflection | Review against a specific rubric and source evidence. Bound revision loops; a critic is not proof of correctness. |
| 15:51 | Tool use | Use local files and commands or configured MCP/plugin capabilities. Inspect actual outputs and permissions. |
| 18:19 | Planning | Ask for milestones, dependencies and acceptance criteria, then update from evidence rather than treating the first plan as fixed. |
| 20:49 | Multi-agent collaboration | Native subagents and custom roles can coordinate focused work. Their instructions do not override inherited permissions. |
| 23:45 | Memory management | Separate current chat context, required project guidance and optional local Codex memories. Avoid a universal-memory promise. |
| 26:42 | Learning and adaptation | Turn a demonstrated correction into a small reviewed instruction, skill or test change, then check it on a fresh case. |
| 29:17 | Goal setting and monitoring | State observable completion criteria, progress and limits. A todo list alone is not an evaluation system. |
| 31:34 | Exception handling and recovery | Classify the failure, retry only when useful, use an approved fallback, or surface a concrete blocker. |
| 34:11 | Human in the loop | Review before a consequential action. Configure actual approval/permission controls as well as task instructions. |
| 36:01 | Retrieval / RAG | Begin with local search or a relevant connected source. Add indexed retrieval when the corpus and query needs justify it. |
| 38:14 | Inter-agent communication | Native child-task instructions and returned findings often replace a hand-built message protocol in an interactive Codex workflow. |
| 43:08 | Resource-aware optimization | Choose the number of agents, scope, model and effort deliberately. More agents incur more model/tool work; measure rather than promise savings. |
| 46:35 | Reasoning techniques | Request a concise plan, assumptions, evidence and checks. Do not teach hidden chain-of-thought extraction or unnecessary debate loops. |
| 49:57 | Evaluation and monitoring | Use representative test cases, deterministic checks and source comparisons; distinguish passed checks from untested behavior. |
| 52:44 | Guardrails and safety | Combine instruction boundaries, host permissions, source trust and review. A prompt-only prohibition is not an enforced sandbox. |
| 56:04 | Prioritization | Rank by impact, urgency, dependencies and risk, and revisit when evidence changes. |
| 59:29 | Exploration and discovery | Bound a research question, inspect sources, compare findings and preserve provenance. Keep exploration separate from authorization to act. |


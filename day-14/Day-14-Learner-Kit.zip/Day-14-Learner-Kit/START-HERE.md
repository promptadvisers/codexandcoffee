# Day 14 · Fast decisions and Codex workflows

This kit accompanies a standalone 45-minute Codex & Coffee workshop.

## Try the Decisions API example

`04-decisions-sorter` contains a local Request Sorter. Its README explains how to start the included server. Replay mode works without an API key and clearly labels its illustrative answers. Live mode needs your own OpenAI API key on the server. The local routing and replay browser checks passed. Live API behavior was not tested because no key was configured.

## Open the finished QuickList example

1. Extract this ZIP to a folder you can keep.
2. Open `02-finished-quicklist/index.html` in your browser.
3. Add a fictional task, tick it off, then use Export as text.
4. Close and reopen the same file with the same browser profile.

QuickList is a local browser app. It uses browser storage. Chromium was tested. Local-file storage behavior can vary between browsers, and private browsing may clear it. Export the list before moving it or clearing browser data.

## Choose a practice route

- `01-build-from-plan` contains the plan without an app. Open this folder in Codex to build your own version.
- `02-finished-quicklist` contains the working example, original plan, build record and model review.
- `03-practice-copy` is a separate copy for the priority-flag exercise.
- `PROMPTS.md` contains the exact prompts shown on the slides.
- `BROWSER-CHECKS.md` records the separate tests on the final app.

Use the desktop Codex project workflow or the CLI. Both need access to the folder you intend to change. If using the CLI, open a terminal in that folder, start `codex`, and enter the same plain-English prompt.

The opening teaches the Decisions API, its three answer types, and a fixed routing rule. The 0.80 threshold is an illustrative classroom choice, and model judgments can vary. Read the official guide and evaluate labeled examples before using a threshold in real work.

The worked sequence used GPT-6.1 Terra to plan, GPT-6.1 Sol to build and GPT-6 Astra to review. This is an example allocation. It does not establish a model performance ranking. Your available models may differ.

## The priority exercise

Use `03-practice-copy`, then paste the exercise prompt from slide 40. Check an existing task as well as a new task. Reopen the app and inspect the text export.

## Try the packaged Relay Voice app

[Open the source, downloads and setup guide](https://github.com/promptadvisers/codexandcoffee/tree/main/day-13/relay-voice).

Choose the Apple Silicon Mac DMG or Windows x64 ZIP. Relay Voice requires your own Gemini API key and microphone access. Mac text insertion also requires Accessibility permission. The published downloads are previews. Their automated and clean-launch checks passed. Physical voice input and text insertion need a hands-on check on your computer.

The desktop QuickList packaging prompt is a follow-on exercise. This kit includes the tested browser version.

## Official references

[Codex CLI](https://developers.openai.com/codex/cli)

[Projects and chats](https://learn.chatgpt.com/docs/projects)

[Choosing models](https://learn.chatgpt.com/docs/models)

[Commands](https://learn.chatgpt.com/docs/developer-commands)

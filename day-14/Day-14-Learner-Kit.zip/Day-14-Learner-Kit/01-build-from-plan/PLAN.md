# QuickList plan

## Simplest version

Build a single-page app that runs locally in a browser, with no account, server, or installation. Keep one persistent list on this computer. “Today” is the label for the list; do not automatically delete or reset tasks at midnight.

## Screen layout

- **Header:** QuickList and a short “Today's tasks” label.
- **Add task:** one text field and an Add button. Enter also adds the task. Ignore blank or whitespace-only entries.
- **Task list:** each task has a checkbox and its text. Checked tasks remain visible with a completed style; unchecking restores them to the remaining count. Show a friendly empty state when there are no tasks.
- **Footer:** show the number of tasks left and an “Export as text” button. Export all tasks in their displayed order, using `[ ]` for open tasks and `[x]` for completed tasks, as a downloadable `quicklist.txt` file.

## Three build steps

1. Create a small responsive page with the header, add form, task list, remaining count, and export button. Use semantic form controls and readable styling.
2. Implement adding and toggling tasks. Store task text and completion state in browser `localStorage`, load them on startup, and update storage after each change.
3. Generate and download the plain-text export. Check the complete flow and fix any issues found.

## Checks

- Add a task with the button and another with Enter; blank input adds nothing.
- Check and uncheck a task; its appearance and the number left update correctly. Completed tasks stay visible.
- Close and reopen the page in the same browser on this computer; tasks and completion states remain.
- Export a mixed list and open `quicklist.txt`; its task text, order, and `[ ]`/`[x]` markers match the screen.
- Confirm the empty state, keyboard controls, and layout work on a narrow screen.

## Handoff for the builder

The project is empty. Implement the plan with plain HTML, CSS, and JavaScript, preferably in a single `index.html` that can be opened locally. Use browser storage for this browser and computer; it does not sync across browsers or devices. Keep the scope to the features above, and do not reset the list automatically. Verify the checks in a browser and note any environment limitations.

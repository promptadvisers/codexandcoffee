# Request Sorter

A small Decisions API teaching example. It chooses Billing, Technical support or General review. The AI supplies a category and confidence. A fixed local rule sends confidence below 0.80, refusals and malformed answers to General review. The threshold is illustrative and needs evaluation against labeled examples before real use.

## Replay the lesson

Install Node.js if needed. Open this folder in Codex and ask it to start the included server, or run `node server.mjs`. Open http://127.0.0.1:4388 and use the five sample buttons.

Replay values are authored examples, not recorded live API results. An arbitrary new request produces an explicit replay-mode message. Local routing and browser checks are recorded separately.

## Use the real API

Create an API key in your OpenAI Platform account and configure `OPENAI_API_KEY` in your local environment. Keep it on the server. Run `node server.mjs --live`. Live requests use `POST /v1/decisions` with `gpt-6-luna` and incur API usage. The app never sends the key to the browser.

No live API call was made during preparation because no key was available. There is no measured latency or accuracy result for this demo. The local replay mode performs no API requests.

## Check the routing

Run `node check.mjs`. Tests cover accepted choices, the threshold boundary, low confidence, invalid choices, malformed answers and refusal. These checks test the app's rules, not the model's judgment. Test the live model on examples you label yourself and inspect errors before selecting a real threshold.

## Official documentation

https://developers.openai.com/api/docs/guides/decisions

https://developers.openai.com/api/reference/resources/decisions/methods/create

# Independent browser checks

The final QuickList file passed these nine checks in Chromium, opened directly as a local file. The checks used fictional tasks and a fresh browser profile.

- Blank input ignored
- Button and Enter add tasks
- Completion updates count
- Unchecking restores count
- Apostrophe, emoji and markup kept as text
- Export includes text and completion markers
- Closing and reopening retains list
- Narrow screen has no horizontal overflow
- No browser runtime errors

These are separate from the model review in REVIEW.md. The model reported that its browser startup was blocked and used logic tests. Other browsers, physical phones and a native QuickList installer were outside this check. Browser storage for a local file can vary by browser.

Source SHA-256

`79e1ed8b756729d0f46ae50e8c49b6baa79c02ee62d0f49bced824a3c502e5fe`

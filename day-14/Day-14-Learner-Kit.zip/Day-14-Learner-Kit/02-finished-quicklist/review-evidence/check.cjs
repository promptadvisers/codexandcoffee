const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
(async () => {
  const profile = await fs.mkdtemp('/tmp/quicklist-review-');
  const url = pathToFileURL(path.resolve('index.html')).href;
  const results = [], errors = [];
  let context;
  async function launch() {
    context = await chromium.launchPersistentContext(profile, { headless: true, acceptDownloads: true, offline: true, viewport: {width: 1000, height: 800} });
    context.on('page', p => p.on('pageerror', e => errors.push(e.message)));
    const p = await context.newPage(); await p.goto(url); return p;
  }
  const pass = s => { results.push(s); console.log('PASS:', s); };
  async function texts(p) { return p.locator('#tasks span').allTextContents(); }
  async function count(p, n) { assert.equal(await p.locator('#remaining').textContent(), `${n} ${n === 1 ? 'task' : 'tasks'} left`); }
  async function download(p, keyboard = false) {
    const pending = p.waitForEvent('download');
    if (keyboard) await p.keyboard.press('Enter'); else await p.locator('#export').click();
    const d = await pending; assert.equal(d.suggestedFilename(), 'quicklist.txt');
    const text = await fs.readFile(await d.path(), 'utf8'); return { d, text };
  }
  try {
    let p = await launch();
    assert.equal(await p.locator('#empty').isVisible(), true); await count(p, 0);
    assert.equal((await download(p)).text, ''); pass('Empty state, zero count, and empty export');
    await p.locator('button[type=submit]').click();
    await p.locator('#task-input').fill('   '); await p.locator('#task-input').press('Enter');
    assert.deepEqual(await texts(p), []); pass('Blank button submission and whitespace Enter submission ignored');
    await p.locator('#task-input').fill("  Buy Sam's groceries  "); await p.locator('button[type=submit]').click();
    assert.equal(await p.locator('#task-input').inputValue(), '');
    assert.equal(await p.locator('#task-input').evaluate(e => e === document.activeElement), true);
    await p.locator('#task-input').fill('Walk the dog 🐕'); await p.locator('#task-input').press('Enter');
    assert.deepEqual(await texts(p), ["Buy Sam's groceries", 'Walk the dog 🐕']); await count(p, 2);
    assert.equal(await p.locator('#empty').isVisible(), false); pass('Add button and Enter; apostrophe, emoji, trimming, focus and input reset');
    const boxes = p.locator('#tasks input');
    await boxes.nth(0).check(); await count(p, 1);
    assert.equal(await p.locator('#tasks span').nth(0).evaluate(e => getComputedStyle(e).textDecorationLine), 'line-through');
    assert.equal(await p.locator('#tasks li').count(), 2);
    await boxes.nth(0).uncheck(); await count(p, 2);
    assert.equal(await p.locator('#tasks span').nth(0).evaluate(e => getComputedStyle(e).textDecorationLine), 'none');
    await p.locator('#task-input').focus(); await p.keyboard.press('Tab');
    assert.equal(await p.locator('button[type=submit]').evaluate(e => e === document.activeElement), true);
    await p.keyboard.press('Tab'); assert.equal(await boxes.nth(0).evaluate(e => e === document.activeElement), true);
    await p.keyboard.press('Space'); await count(p, 1);
    pass('Tick, untick, completed styling, retained rows, remaining count, Tab and Space');
    await context.close(); p = await launch();
    assert.deepEqual(await texts(p), ["Buy Sam's groceries", 'Walk the dog 🐕']);
    assert.equal(await p.locator('#tasks input').nth(0).isChecked(), true);
    assert.equal(await p.locator('#tasks input').nth(1).isChecked(), false); await count(p, 1);
    pass('Closed entire browser and reopened same file/profile; text, order and mixed completion persisted');
    await p.locator('#tasks input').nth(1).focus(); await p.keyboard.press('Tab');
    assert.equal(await p.locator('#export').evaluate(e => e === document.activeElement), true);
    const exported = await download(p, true);
    assert.equal(exported.text, "[x] Buy Sam's groceries\n[ ] Walk the dog 🐕\n");
    await exported.d.saveAs('review-evidence/quicklist.txt'); pass('Keyboard export downloaded quicklist.txt with exact UTF-8 text, order and markers');
    await p.setViewportSize({width: 320, height: 700});
    await p.screenshot({path:'review-evidence/narrow.png', fullPage:true});
    assert.equal(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    await p.locator('#task-input').fill('x'.repeat(250)); await p.locator('button[type=submit]').click();
    assert.equal(await p.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
    await p.locator('#tasks input').last().check(); await count(p, 1);
    pass('320px layout, long unbroken text, Add and checkbox controls without horizontal overflow');
    assert.deepEqual(errors, []); pass('No uncaught browser JavaScript errors');
    await fs.writeFile('review-evidence/results.json', JSON.stringify({date: '2026-11-12', browser: context.browser().version(), results, errors}, null, 2)+'\n');
  } finally { if (context) await context.close(); await fs.rm(profile, {recursive:true, force:true}); }
})().catch(e => { console.error(e); process.exitCode = 1; });

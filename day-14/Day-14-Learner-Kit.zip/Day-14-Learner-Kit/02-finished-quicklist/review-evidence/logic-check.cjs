// Minimal DOM/storage harness: exercises the actual inline script, not a browser.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('index.html', 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
class Element {
  constructor(tag) { this.tag = tag; this.children = []; this.handlers = {}; this.value = ''; this.textContent = ''; }
  append(...nodes) { this.children.push(...nodes); }
  addEventListener(name, fn) { this.handlers[name] = fn; }
  focus() { this.focused = true; }
  click() { this.handlers.click?.({preventDefault(){}}); }
  remove() {}
}
function open(storage, failWrite = false) {
  const ids = Object.fromEntries(['add-form','task-input','tasks','empty','remaining','storage-message','export'].map(id => [id, new Element(id)]));
  const blobs = [], links = [];
  ids['add-form'].reset = () => { ids['task-input'].value = ''; };
  vm.runInNewContext(script, {
    document: {querySelector: s => ids[s.slice(1)], createElement: tag => { const e = new Element(tag); if(tag === 'a') links.push(e); return e; }, body: new Element('body')},
    localStorage: {getItem: k => storage[k] ?? null, setItem: (k,v) => {if (failWrite) throw Error('quota'); storage[k] = v;}},
    Blob, URL: { createObjectURL: b => {blobs.push(b); return 'blob:test';}, revokeObjectURL() {} }, setTimeout: fn => fn()
  });
  return { ids, blobs, links,
    add(text) {ids['task-input'].value = text; ids['add-form'].handlers.submit({preventDefault(){}});},
    toggle(i, done) {const cb = ids.tasks.children[i].children[0].children[0]; cb.checked = done; cb.handlers.change();},
    texts() {return ids.tasks.children.map(r => r.children[0].children[1].textContent);}
  };
}
(async () => {
  const results = []; const pass = s => {results.push(s); console.log('PASS:', s);};
  const storage = {}; let app = open(storage);
  assert.equal(app.ids.empty.hidden, false); assert.equal(app.ids.tasks.hidden, true); assert.equal(app.ids.remaining.textContent, '0 tasks left');
  app.add(''); app.add('   \t '); assert.deepEqual(app.texts(), []); pass('Empty state and blank/whitespace submission');
  app.add("  Buy Sam's groceries  "); app.add('Walk the dog 🐕');
  assert.deepEqual(app.texts(), ["Buy Sam's groceries", 'Walk the dog 🐕']);
  assert.equal(app.ids['task-input'].value, ''); assert.equal(app.ids.remaining.textContent, '2 tasks left'); assert.equal(app.ids.empty.hidden, true);
  pass('Adding apostrophe and emoji, trimming, input clearing, remaining count');
  app.toggle(0, true); assert.equal(app.ids.remaining.textContent, '1 task left'); assert.equal(app.texts().length, 2);
  app.toggle(0, false); assert.equal(app.ids.remaining.textContent, '2 tasks left');
  app.toggle(0, true); pass('Tick and untick update count, retain tasks and write storage');
  app = open(storage); assert.deepEqual(app.texts(), ["Buy Sam's groceries", 'Walk the dog 🐕']);
  assert.equal(app.ids.tasks.children[0].children[0].children[0].checked, true);
  assert.equal(app.ids.tasks.children[1].children[0].children[0].checked, false);
  assert.equal(app.ids.remaining.textContent, '1 task left'); pass('Fresh script instance reloads text/order/completion from shared storage mock');
  app.ids.export.click(); assert.equal(app.links[0].download, 'quicklist.txt');
  const exported = await app.blobs[0].text(); assert.equal(exported, "[x] Buy Sam's groceries\n[ ] Walk the dog 🐕\n");
  fs.writeFileSync('review-evidence/export-content.txt', exported); pass('Export Blob content and requested filename match mixed list exactly');
  const empty = open({}); empty.ids.export.click(); assert.equal(await empty.blobs[0].text(), ''); pass('Empty export');
  app.add('<b>literal</b>'); assert.equal(app.texts()[2], '<b>literal</b>'); pass('HTML-like task assigned as literal textContent');
  const invalid = open({'quicklist.tasks':'broken json'}); assert.equal(invalid.ids['storage-message'].textContent, 'Saved tasks could not be loaded.'); invalid.add('Recover'); pass('Malformed storage handled; adding still works');
  const quota = open({}, true); quota.add('Keep me'); assert.deepEqual(quota.texts(), ['Keep me']); assert.match(quota.ids['storage-message'].textContent, /could not save/); quota.ids.export.click(); assert.equal(await quota.blobs[0].text(), '[ ] Keep me\n'); pass('Storage write failure preserves current task and export with warning');
  fs.writeFileSync('review-evidence/logic-results.json', JSON.stringify({date:'2026-11-12', environment:'Node VM with minimal DOM and storage mocks; not browser verification', results}, null, 2)+'\n');
})().catch(e => {console.error(e); process.exitCode = 1;});

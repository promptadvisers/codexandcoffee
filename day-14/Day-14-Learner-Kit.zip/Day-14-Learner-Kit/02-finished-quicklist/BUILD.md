# QuickList build

QuickList is a single offline HTML page with a navy, cream, and teal layout, large controls, a live remaining count, and plain-text export. Tasks and completion states are saved in browser `localStorage` with no daily reset.

Double-click [index.html](index.html) to open it in a browser. To return to your saved tasks, open the same file from the same location in the same browser profile.

## Checks run

Passed in headless Chromium with `index.html` opened directly from disk and networking disabled.

- Added tasks with the Add button and Enter. Empty and whitespace-only input added nothing.
- Checked and unchecked a task. Verified that completed tasks stayed visible, the strike-through changed, and the remaining count updated.
- Closed Chromium and reopened the file in the same test profile. Both tasks, their order, and their completion states persisted.
- Downloaded and read `quicklist.txt`. Both task texts, their order, and the `[ ]` and `[x]` markers matched the list.
- Checked the empty state and a 320 px layout. Verified keyboard focus, Space to toggle a task, and Enter to export.

Browser verification was limited to Chromium. [PLAN.md](PLAN.md) contains the original plan for the next build session.

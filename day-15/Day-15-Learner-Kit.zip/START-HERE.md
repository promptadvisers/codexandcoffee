# Your One-Person Army

Choose one repeated job from the 180-use-case catalog. You can be an employee, freelancer, manager or business owner.

1. Open USE-CASES.html for the searchable catalog, or USE-CASES.md for a readable list.
2. Copy workspace-template to a folder of your own and open that folder as a Codex project.
3. Fill in shared conventions and the selected department’s brief, bottleneck and systems. Add the relevant current inputs.
4. Copy the department discovery prompt from PROMPTS.md. Replace the brackets with your own context and documentation links.
5. Choose one proposal and use the build prompt in the same chat. Test a small sample and inspect the result.
6. When the method works, use the reuse or scheduling prompt. MODEL-GUIDE.md explains starting model choices and the difference between scheduled work and a connected application.

The template contains no credentials, live connections or activated jobs. The use cases and prompts are adaptable planning material, not a package of preconfigured automations. Recruitment and HR examples support administrative work; responsible people retain employment decisions.

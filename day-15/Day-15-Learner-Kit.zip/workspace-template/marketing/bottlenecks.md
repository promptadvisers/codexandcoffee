# Our bottleneck

Example: We have good source material but struggle to turn it into consistent campaigns.

Replace this with your repeated job, frequency, time spent, current failure and desired result.

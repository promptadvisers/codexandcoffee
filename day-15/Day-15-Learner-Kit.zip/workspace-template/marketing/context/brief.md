# Marketing context

## Goals
[What we need to achieve]

## Useful sources
Our audience, brand guide, approved claims, content examples, assets and campaign goals.

## Approved rules
[Decisions, limits and standards to follow]

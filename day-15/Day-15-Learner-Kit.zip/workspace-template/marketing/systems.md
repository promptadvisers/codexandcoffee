# Systems and access

Likely sources: Website, email platform, social scheduler and analytics.

For each actual system, add: name, official documentation URL, available connector or API, data owner, and permitted scope. Keep passwords and API keys outside this file.

# Shared context

Add a short business or team brief, approved facts, responsibilities, offers and links to authoritative documents.

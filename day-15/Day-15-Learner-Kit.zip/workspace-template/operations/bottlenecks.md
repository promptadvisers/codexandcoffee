# Our bottleneck

Example: Work gets lost between meetings, requests and delivery.

Replace this with your repeated job, frequency, time spent, current failure and desired result.

# Systems and access

Likely sources: Project tracker, calendar, forms, documents and internal tools.

For each actual system, add: name, official documentation URL, available connector or API, data owner, and permitted scope. Keep passwords and API keys outside this file.

# Operations context

## Goals
[What we need to achieve]

## Useful sources
Our procedures, meeting notes, project plans, owners, service targets and current task list.

## Approved rules
[Decisions, limits and standards to follow]

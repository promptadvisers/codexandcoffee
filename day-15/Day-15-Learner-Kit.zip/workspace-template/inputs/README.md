# Prepared inputs

Add current exports, transcripts or documents needed for the task. Record dates and preserve original sources.

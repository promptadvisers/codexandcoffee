# Systems and access

Likely sources: HR system, document store, forms, training platform and calendar.

For each actual system, add: name, official documentation URL, available connector or API, data owner, and permitted scope. Keep passwords and API keys outside this file.

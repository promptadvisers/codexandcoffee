# Our bottleneck

Example: People ask the same questions and routine employee processes are hard to track.

Replace this with your repeated job, frequency, time spent, current failure and desired result.

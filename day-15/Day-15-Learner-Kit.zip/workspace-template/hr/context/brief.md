# HR context

## Goals
[What we need to achieve]

## Useful sources
Our approved policies, templates, onboarding steps, training materials and HR service process.

## Approved rules
[Decisions, limits and standards to follow]

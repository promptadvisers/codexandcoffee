# Systems and access

Likely sources: CRM, email, calendar and proposal tool.

For each actual system, add: name, official documentation URL, available connector or API, data owner, and permitted scope. Keep passwords and API keys outside this file.

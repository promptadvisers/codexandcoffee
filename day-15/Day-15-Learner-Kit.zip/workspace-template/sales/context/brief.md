# Sales context

## Goals
[What we need to achieve]

## Useful sources
Our offers, price rules, CRM fields, recent call notes and approved case studies.

## Approved rules
[Decisions, limits and standards to follow]

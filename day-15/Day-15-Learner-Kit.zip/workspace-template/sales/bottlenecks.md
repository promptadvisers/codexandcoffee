# Our bottleneck

Example: Leads take too long to become a useful next conversation.

Replace this with your repeated job, frequency, time spent, current failure and desired result.

# Recruitment context

## Goals
[What we need to achieve]

## Useful sources
Our approved role brief, job-related criteria, interview process, message templates and hiring timeline.

## Approved rules
[Decisions, limits and standards to follow]

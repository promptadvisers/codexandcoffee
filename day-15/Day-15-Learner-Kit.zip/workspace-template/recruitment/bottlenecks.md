# Our bottleneck

Example: Coordinating the hiring process takes time away from talking with candidates.

Replace this with your repeated job, frequency, time spent, current failure and desired result.

# Systems and access

Likely sources: Applicant tracking system, careers page, calendar and email.

For each actual system, add: name, official documentation URL, available connector or API, data owner, and permitted scope. Keep passwords and API keys outside this file.

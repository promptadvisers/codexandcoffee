# Conventions

Fill in your approved writing style, output templates, naming rules, business policies and review requirements.

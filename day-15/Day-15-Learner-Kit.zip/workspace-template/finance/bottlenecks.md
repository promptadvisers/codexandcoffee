# Our bottleneck

Example: We spend too much time cleaning records and chasing unexplained differences.

Replace this with your repeated job, frequency, time spent, current failure and desired result.

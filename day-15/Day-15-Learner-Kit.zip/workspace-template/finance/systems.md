# Systems and access

Likely sources: Accounting tool, bank exports, billing system and spreadsheets.

For each actual system, add: name, official documentation URL, available connector or API, data owner, and permitted scope. Keep passwords and API keys outside this file.

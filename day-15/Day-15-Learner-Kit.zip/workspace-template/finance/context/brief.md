# Finance context

## Goals
[What we need to achieve]

## Useful sources
Our invoice and payment exports, account categories, approval rules and reporting templates.

## Approved rules
[Decisions, limits and standards to follow]

# How image models learn and generate

## Pictures and words provide examples

Training can use pictures paired with descriptions. The description helps connect a visual feature with language. OpenAI's CLIP paper describes learning to match captions with images. CLIP learns useful representations; it is not itself an image generator. The bottle pairs in this lesson are illustrations, not a disclosed training dataset. [CLIP paper](https://arxiv.org/abs/2103.00020)

## Training adjusts learned settings

A model makes a prediction, measures error against a training target, and adjusts numerical weights to reduce that error. This repeats across examples. The target varies with the method: a matching caption, a visual code, or noise added to an image. The lesson's loop is a simplified explanation, not the unpublished GPT Image 2.6 recipe.

## Captions affect what the model can learn

“A bottle” leaves many visual relationships unnamed. A detailed caption can describe the cap, material and relative positions. OpenAI's DALL·E 3 research found that training with more descriptive generated captions improved prompt following. That is evidence about DALL·E 3, not proof that 2.6 uses the same training process. [Caption research](https://cdn.openai.com/papers/dall-e-3.pdf)

## Diffusion is one published method

During diffusion training, noise is added to an image and the model learns a denoising prediction. Generation starts from noise and applies learned steps to create a sample. A text-conditioned system also uses the description to guide the result. The slide panels illustrate this idea; they are not recordings of a model run. OpenAI's DALL·E 2 used a diffusion decoder. [Diffusion paper](https://arxiv.org/abs/2006.11239), [DALL·E 2 paper](https://arxiv.org/abs/2204.06125)

## Visual tokens are another published approach

The original DALL·E encoded pictures into a grid of learned visual codes and modeled text and image tokens in sequence. A token is a code for image content, not necessarily one pixel. This illustrates why “an image model” does not mean one universal architecture. [DALL·E paper](https://arxiv.org/abs/2102.12092)

## What the current 2.6 docs explain

GPT Image 2.6 accepts text and image inputs. Its API separates planning complexity from rendering quality. It supports edits guided by a separate transparent annotation layer. For SVG output, the documented workflow first makes a reference image, then uses an authoring model to produce paths and shapes. These are documented capabilities and workflows; the reviewed docs do not publish the full neural architecture or training recipe. [Image-generation guide](https://developers.openai.com/api/docs/guides/image-generation)

## What this changes about your prompts

A reference is input to a request; attaching it does not retrain the underlying model. Supply the details the model should preserve, describe the intended change, and compare the result with the reference. Use the original image as a separate slide layer when identical source artwork matters. Our custom bottle examples used Codex's image tool without an exposed backend model ID, so they demonstrate the workflow rather than a verified 2.6 benchmark.

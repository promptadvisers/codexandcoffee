# Make images that belong together

Start with `reference/ASTER-master.png`. ASTER is a fictional water-bottle brand for this lesson. No coding experience is needed.

## Start with a consistent slide style

For illustrations of different topics, attach `reference/deck-style-reference.png` and use `prompts/deck-planning-template.txt` or `prompts/deck-review-template.txt`. These are templates, not previously executed requests. Both keep the same style wording; only the subject sentence changes. Slide 6 shows what stays fixed and slide 7 compares the complete prompts.

Use a style reference to carry the visual treatment. Use a product/character reference to preserve identity. Keep real logos and exact headings as separate files or editable PowerPoint text. For API use, set dimensions such as 1536×864 in the request; wording such as “16:9” does not set that field for you. Check every result.

## Follow the workshop

1. Open the master and identify the cap, neck grooves, body shape, white word/star and base stripe.
2. In an image-capable Codex chat, attach the master and paste `prompts/03-reference-kitchen.txt`. Ask for an image, not an analysis. Use the image-generation feature available in your account. The class does not require API setup.
3. Compare the returned image with the master using `WORKSHEET.md`. Check format and empty space as well as the product.
4. For your own scene, use `prompts/slide-52.txt`. Replace `[your setting]` with a café counter, park bench or another simple location.
5. If needed, use `prompts/slide-54.txt` to request one specific repair. Attach both the master and your current result.
6. For a slide series with identical artwork, use `prompts/slide-45.txt`. This asks for slide assembly using the original PNG, not regeneration of the bottle.

If image generation is unavailable or takes longer than four minutes, work with the supplied `observed-results` images. The review and repair exercise still works. Do not spend the class installing anything or purchasing access.

## Folder guide

- `reference`: the one approved master image
- `prompts`: exact completed requests and clearly labeled practice templates, also keyed to slide numbers
- `observed-results`: actual returned images, including deliberate comparison examples with drift or format problems
- `backgrounds`: generated empty sets for separate product-layer assembly
- `MODEL-MECHANICS.md`: training, diffusion, visual tokens and the documented 2.6 workflows
- `WORKSHEET.md`: identity/framing checks and acceptance decision
- `ANSWER-KEY.md`: observed issues in the prepared examples
- `VISUAL-BRIEF.md`: reusable style and placement rules

The numbered scene requests are verbatim production prompts. `01-master.txt` is the complete original master request; slides 28 and 29 split it for readability. Slide 31 contains explanatory excerpts, not a second exact request. Follow-up, style and lab prompts are templates, not claimed completed tests. The slide-45 recipe describes the native assembly demonstrated on slides 42–44.

## Model facts and evidence

OpenAI’s November 4, 2026 changelog names GPT Image 2.6 Sunburst and Flare. Official docs describe reference-image editing and separate complexity/quality controls. Their full neural architecture is not disclosed. Custom bottle examples came from Codex’s built-in image tool, which did not expose a backend model ID; they are not verified 2.6 benchmark runs. The football images in the deck are OpenAI’s published Sunburst examples at medium quality with different complexity settings.

Sources: [Changelog](https://developers.openai.com/api/docs/changelog), [Image generation](https://developers.openai.com/api/docs/guides/image-generation), [Sunburst](https://developers.openai.com/api/docs/models/gpt-image-2.6-sunburst), [Flare](https://developers.openai.com/api/docs/models/gpt-image-2.6-flare).

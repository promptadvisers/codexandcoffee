# ASTER visual brief

The approved identity is the image in `reference/ASTER-master.png`, including its actual returned silhouette. The initial prompt asked for a rounded rectangle, but we approved the returned rounded bottle. Judge later images against the approved image rather than silently pretending the original shape request was fulfilled.

Fixed product details:
- Coral-orange flat cap and black seal
- Two shallow neck grooves
- Same front-view silhouette and proportions
- White ASTER word with a four-point star beneath it
- Thin white stripe near the base

Shared treatment: matte cobalt product, coral accent, warm ivory environment, soft light from the upper left. Full product, straight front angle, quiet left half for a headline. Put slide text in native text objects. For identical product artwork, reuse the master PNG as a separate layer at the same scale. Match its lighting as closely as possible with the background; a reused image cannot acquire physically accurate new reflections by itself.

For a genuine product’s unseen side or back, provide more reference views or use a product render. A front photo alone does not specify those surfaces.

OpenAI official examples shown on slides 23 and 24. These are published examples, not fresh runs. Source: https://developers.openai.com/api/docs/guides/image-generation

For the markup example, official-kitchen.webp is the original first input. official-markup-overlay.png is the separate transparent annotation layer. markup-after.webp is the published output. Send the original and overlay separately when using the supported Image API; the flattened circled image shown in the deck is a visualization of these inputs, not the annotation layer itself. Exact prompt: ../prompts/slide-23.txt.

svg-sunburst.svg is the actual published Field & Flour SVG, so you can inspect its editable paths. The slide shows a rendered preview. No API credentials are supplied or required to inspect these files.

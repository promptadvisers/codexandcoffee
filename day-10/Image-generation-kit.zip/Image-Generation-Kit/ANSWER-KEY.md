# Prepared-example answer key

These are observations from a small illustrative set, not reliability measurements.

- `loose-kitchen.png`: a new, slimmer body; no four-point star; no base stripe; neck details differ from the master. The photo is attractive but not the same approved product.
- `loose-repeat.png`: the exact same text-only prompt returned another shape and scene. Repeating text did not fix identity.
- `reference-kitchen.png`: visible cap/seal, neck grooves, word/star and stripe are much closer to the master. The returned canvas is portrait even though the request called for a landscape composition and left-side space. Reject the framing for the intended slide.
- `reference-studio.png`: the key visible identity markers carry over; the returned portrait canvas again misses the requested landscape presentation. Do not claim exact pixel preservation.
- `reference-terrace.png`: the key identity markers remain visible and the canvas is landscape. Inspect apparent proportions, wording, lighting and available headline space for the intended use rather than assigning an automatic pass.

Some deck comparisons crop the full outputs to enlarge the bottle. Use the uncropped files here to judge original format and framing.

Slides 42–44 reuse the identical approved PNG bytes at the same size. The background and final composited edge pixels differ. The method preserves the source artwork; it does not create new product lighting or reveal hidden surfaces.

The master itself did not fully follow the requested rounded-rectangle silhouette. We explicitly approved the returned image as our reference. This is why the reference file, not a vague remembered description, governs later checks.

# Image review worksheet

File reviewed:
Intended use:
Master reference:

For each check, write PASS, REPAIR or UNSURE and describe what you see.

- Cap and seal:
- Neck grooves:
- Body shape/proportions:
- ASTER word and four-point star:
- Thin white base stripe:
- Full bottle and camera angle:
- Requested image format:
- Quiet space for the headline:
- Plausible light, contact shadow and surface:

Most important difference:
One specific follow-up request:
What must remain unchanged:
Success check for the follow-up:

Decision: accept / repair / reuse the original asset
Reason for that decision:

## Three-minute comparison exercise (slide 34)

One minute: inspect all five identity features. One minute: compare framing and light with a partner. One minute: decide which outputs you would accept for a product page, and which for a mood board. If working alone, write both decisions before opening the answer key.

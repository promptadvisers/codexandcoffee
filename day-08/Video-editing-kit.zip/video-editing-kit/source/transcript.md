# Original recording transcript

Fictional demo with synthetic narration. Times are source seconds, with conservative whole-phrase boundaries. The screen-inspection pause is intentional.

**take-1 | 0.000–4.133s**
Today we will edit a video. Actually, let me start that again.

**opening | 5.933–9.133s**
Today we will turn a rough recording into a clean video.

**backup | 9.800–14.300s**
First, keep a copy of the original. Then choose which takes to keep.

**price-retake | 15.400–19.733s**
The starter kit costs fifty dollars. Sorry, fifteen dollars.

**price | 20.533–25.033s**
The starter kit costs fifteen dollars, and you can try it before you buy.

**screen | 25.767–30.933s**
Watch the screen while I show these three steps. [Pause to let viewers inspect the screen.]

**close | 30.933–35.967s**
Listen to every join. Check the words, check the timing, and keep the original.
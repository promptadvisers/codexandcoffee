#!/usr/bin/env python3
"""Render approved source-time ranges without changing the original."""
import argparse,json,subprocess,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--plan',default='edits/cut-list.json');p.add_argument('--out',default='exports/clean-edit.mp4');a=p.parse_args()
root=Path(__file__).resolve().parents[1];planpath=root/a.plan;plan=json.loads(planpath.read_text());source=(root/plan['source']).resolve();out=(root/a.out).resolve()
if not source.is_relative_to(root) or not out.is_relative_to(root):raise SystemExit('Source and output must stay inside this learner folder')
if out==source or out.exists():raise SystemExit('Choose a new output filename; originals and previous exports are preserved')
probe=json.loads(subprocess.check_output(['ffprobe','-v','quiet','-show_format','-show_streams','-of','json',str(source)]));duration=float(probe['format']['duration']);fps=plan.get('fps',30)
if not any(s['codec_type']=='audio' for s in probe['streams']):raise SystemExit('This exercise expects audio and video')
rows=plan['keep'];last=0;filters=[];links=[];mapping=[];edited=0
if not rows:raise SystemExit('The plan has no keep ranges')
for i,row in enumerate(rows):
 s,e=float(row['start']),float(row['end'])
 if not 0<=s<e or e>duration+0.000001 or s<last:raise SystemExit('Keep ranges must be valid and in source order')
 if abs(s*fps-round(s*fps))>0.001 or abs(e*fps-round(e*fps))>0.001:raise SystemExit('Use frame-aligned timestamps for this exercise')
 filters.extend([f'[0:v]trim=start={s}:end={e},setpts=PTS-STARTPTS[v{i}]',f'[0:a]atrim=start={s}:end={e},asetpts=PTS-STARTPTS[a{i}]']);links.append(f'[v{i}][a{i}]')
 mapping.append(dict(id=row.get('id',str(i)),source_start=s,source_end=e,edited_start=round(edited,6),edited_end=round(edited+e-s,6)));edited+=e-s;last=e
filters.append(''.join(links)+f'concat=n={len(rows)}:v=1:a=1[v][a]');out.parent.mkdir(parents=True,exist_ok=True)
before=hashlib.sha256(source.read_bytes()).hexdigest()
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-n','-i',str(source),'-filter_complex',';'.join(filters),'-map','[v]','-map','[a]','-c:v','libx264','-preset','veryfast','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-movflags','+faststart',str(out)],check=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==before
receipt={'source_sha256':before,'plan':str(planpath.relative_to(root)),'output':str(out.relative_to(root)),'expected_duration':round(edited,6),'mapping':mapping}
out.with_suffix('.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))

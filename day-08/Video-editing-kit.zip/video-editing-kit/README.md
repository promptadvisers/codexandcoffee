# Editing video with Codex

Start with [SETUP.md](SETUP.md). This fictional recording uses a synthetic voice and no private footage. The goal is to remove abandoned takes while preserving the complete corrected price, the offer to try before buying, and the pause that lets viewers inspect the screen.

1. Play `source/rough-recording.mp4` (36.63 seconds) and read `source/transcript.md`.
2. Open this folder in Codex. Use GPT-6.1 Terra as the starting model. The included AGENTS.md handles the file names and cut-list format so you can make everyday requests.
3. Copy `prompts/inspect.txt`, then `prompts/plan.txt`. Read the generated plan before continuing.
4. Copy `prompts/render.txt`. Or run `python3 scripts/render_edit.py` from this folder after reviewing `edits/cut-list.json`.
5. Compare the new export with `examples/clean-edit.mp4` (25.33 seconds). Read the saved mapping in `examples/clean-edit.json` and listen to `examples/join-review.wav`.
6. Try `prompts/practice.txt` before reading the worked cut list in `examples/`.
7. Optional: copy `graphics/`, use `prompts/graphics.txt`, and review the resulting MP4.

`edits/` starts with the observed Terra plan so the rendering step also works without a model call. To test planning from scratch, move those two files aside in your rehearsal copy. `examples/` contains the worked answers and finished files.

## Useful files

- `source/`: immutable original, source-frame artwork, manually assembled transcript and FFprobe report
- `edits/`: source-time cut plan and reasons
- `scripts/render_edit.py`: local audio/video trim and join helper, with basic path/timing safeguards
- `prompts/`: exact copyable classroom requests
- `examples/`: prepared 25.33-second result, cut plan, mapping and audio join samples
- `graphics/`: editable six-second HyperFrames graphic and its finished render
- `exports/`: your new files
- `AUDIO-AND-CAPTIONS.md`: optional sound and caption steps

## What was actually tested

The exact conversational cut-plan prompt was rehearsed in a fresh GPT-6.1 Terra session. It kept two source ranges and removed the false start and wrong-price take. A separate session rendered that accepted plan. It corrected a tiny time-rounding check, and a clean-folder rerun reproduced the supplied export. The model did not listen to the recording or evaluate footage visually. The plan removed both abandoned takes and kept the correct price, offer and screen pause. The supplied Python/FFmpeg helper rendered it, and checks confirmed duration, streams, source preservation and high audio correlation to the retained source ranges. This is a small worked example, not a comparison benchmark between models.

HyperFrames 0.9.9 rendered the supplied six-second graphic locally. Structure, runtime, layout, contrast and first-frame checks passed. It is a silent title card intended to sit between or over separately edited footage. Auphonic was explained but not run; nothing was uploaded to it.

A person should listen to the final edit and decide whether the pace and joins feel natural. Automated checks cannot make that editorial judgment.

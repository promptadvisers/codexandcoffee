# A six-second editable graphic

`index.html` places one scene on the timeline. `compositions/title.html` holds the design, headline and movement. `assets/gsap.min.js` is the bundled animation runtime (GSAP 3.15.0, copyright GreenSock, standard license at https://gsap.com/standard-license/). `renders/title-card.mp4` is the tested result.

From this folder, with Node.js installed:

```sh
npx hyperframes@0.9.9 check
npx hyperframes@0.9.9 snapshot --at 0,2,5
npx hyperframes@0.9.9 render --output demo.mp4
```

The first command can download the project-local CLI package through npm. HyperFrames may fetch fonts when rendering; this is not a fully offline build toolchain. The supplied MP4 plays offline. Read `npx hyperframes@0.9.9 render --help` for version-specific options.

Try the exact request in `../prompts/graphics.txt`. Change the headline in the scene file or configure the scene variable. Keep the original render and create a new output. The demo is silent by design.

[Official HyperFrames source and documentation](https://github.com/heygen-com/hyperframes)

# Audio, captions and a finished export

## Optional Auphonic step

Auphonic processes a mixed mono/stereo track with leveling, noise reduction and related audio tools. It requires an account and uploads media to its service. The lesson does not require it, and no Auphonic job was run for this kit.

For a locked edit:

1. Extract the edited audio to a new WAV file.
2. Process a copy with conservative leveling and noise settings. Keep speech/music/silence cutting and other time-changing features off.
3. Compare the same passage before and after. Listen for metallic speech or swallowed words.
4. Verify that duration and sync still match the video before replacing its audio.
5. Watch the final muxed file, including the beginning and end.

A target such as **−14 LUFS** and **−1 dBTP** is one web-delivery example, not a universal requirement. Use your destination’s delivery requirements. LUFS measures perceived loudness; dBTP measures true peaks. Neither guarantees pleasant sound.

Ask Codex:

> Extract a WAV copy from my edited MP4. Preserve the MP4. After I provide processed audio, compare durations and help replace the audio only if timing is unchanged. Save a new MP4 and flag sync checks I need to do.

## Captions

The example `examples/clean-edit.srt` uses the final edited timeline. It is a manually timed classroom example, not an automatic speech-recognition result. Check it while playing the video. For production, shorten caption chunks at natural phrase boundaries and refine their timing.

SRT stays editable and can be loaded by compatible players. Burned-in captions become pixels in the exported video. Keep a sidecar copy even if you burn captions into a version.

Ask Codex:

> Create captions for the final edit. Verify names, prices and negations against the recording. Keep captions readable, clear of important controls and synchronized to the edited timeline. Save an SRT before making any burned-in version.

## Screen recordings and formats

Preserve already-recorded cursor movement, zoom and picture-in-picture unless you deliberately change them. A centre crop to portrait can hide necessary controls. Use a full-screen inset or redesign the composition when appropriate.

MP4 is the container. H.264 video and AAC audio are common compatible choices inside it. A high-quality master and a smaller delivery version serve different purposes. Source frame rate, colour and recording quality still constrain the result.

Official references: [Auphonic audio algorithms](https://auphonic.com/help/algorithms/index.html), [FFmpeg filters](https://ffmpeg.org/ffmpeg-filters.html), [FFmpeg documentation](https://ffmpeg.org/ffmpeg.html).

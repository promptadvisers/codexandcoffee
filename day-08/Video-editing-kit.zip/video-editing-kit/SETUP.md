# Before the first edit

Open this learner-kit folder in Codex. Choose **GPT-6.1 Terra** if it is available in your plan and workspace. The lesson uses the Codex app; the equivalent model selection in the CLI is `codex -m gpt-6.1-terra`.

Ask Codex: “Check whether FFmpeg and FFprobe are installed. Report their versions. Do not install anything yet.”

FFmpeg cuts and exports media. FFprobe reads what is in a media file. Python 3 runs this kit’s small rendering helper. The optional HyperFrames graphic needs Node.js and an npm-compatible package manager. Package commands may download dependencies if they are not cached.

If something is missing, ask Codex for setup instructions for your operating system. Inspect the commands before approving installation. Official starting points: [FFmpeg downloads](https://ffmpeg.org/download.html), [Node.js](https://nodejs.org/en/download), [Python](https://www.python.org/downloads/). No global installs are needed for HyperFrames in this kit.

If you want to follow without installing anything, play `source/rough-recording.mp4`, read `source/transcript.md`, write a proposed cut plan, and compare it with `examples/cut-list.json` and `examples/clean-edit.mp4`. A media player and text editor are sufficient.

For a clean rehearsal, copy the learner-kit folder. The `exports/` directory starts empty. Keep original files and previous exports. Commands in this kit run locally. Transcripts sent to Codex still go to the model service; only use footage and text you are allowed to process.

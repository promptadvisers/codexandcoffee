# Day 12 · Your personal assistant, in Codex and beyond

35 slides · 55 minutes

## Presenting the lesson

The story has two parts: use native Codex features, then understand and build a custom assistant with the Codex SDK. Keep personal-calendar examples brief. The demo images are prepared, so no live typing is necessary.

The SDK app produced an actual response and a continuation using the local ChatGPT-authenticated Codex client. Native scheduling and phone pairing are documented setup flows; no live pairing or scheduled job was created. Gratis screenshots use synthetic documentation data. The installed package was verified to include the SDK. Its inspected UI was using Claude.

## Clock

| Slide | Minutes | Topic |
|---|---|---|
| 1 | 0–0.5 | Your personal assistant, in Codex and beyond |
| 2 | 0.5–1.5 | The question behind this lesson |
| 3 | 1.5–3 | Two ways to make your assistant |
| 4 | 3–3.25 | Use Codex itself |
| 5 | 3.25–5.25 | The native assistant building blocks |
| 6 | 5.25–6.75 | One project, focused conversations |
| 7 | 6.75–8.25 | Define the job before scheduling it |
| 8 | 8.25–9.75 | Give the chat a standing job |
| 9 | 9.75–11 | Plugins provide the connections |
| 10 | 11–13 | A prompt becomes a scheduled job |
| 11 | 13–14.5 | Schedule the job in this chat |
| 12 | 14.5–16 | Choose where scheduled results appear |
| 13 | 16–17.5 | Your phone can steer your computer |
| 14 | 17.5–19.5 | Connect your phone to Codex |
| 15 | 19.5–21 | What you can ask from your phone |
| 16 | 21–23 | Where the work actually runs |
| 17 | 23–24.5 | Native assistant or custom app? |
| 18 | 24.5–24.75 | Build your own assistant |
| 19 | 24.75–26.75 | An SDK is a ready-made developer kit |
| 20 | 26.75–28.75 | API, SDK, and app server |
| 21 | 28.75–30.25 | Your app keeps the interface |
| 22 | 30.25–32.25 | Using a Codex subscription |
| 23 | 32.25–33.75 | Gratis: a real custom assistant app |
| 24 | 33.75–35.25 | Give an assistant its own identity |
| 25 | 35.25–36.75 | What an assistant is made of |
| 26 | 36.75–38.75 | What Gratis adds around Codex |
| 27 | 38.75–40.25 | The small piece that calls Codex |
| 28 | 40.25–42 | A tiny app using the real SDK |
| 29 | 42–43 | The same conversation can continue |
| 30 | 43–44.5 | Choose the integration for the job |
| 31 | 44.5–46.5 | A prompt to build your first version |
| 32 | 46.5–48 | The SDK does not build every feature |
| 33 | 48–49.5 | Native Codex and Gratis, side by side |
| 34 | 49.5–54.5 | Design one assistant worth keeping |
| 35 | 54.5–55 | Your assistant starts with one useful job |

## 1. Your personal assistant, in Codex and beyond
**0–0.5 minutes**

Today is about two ways to get an assistant that works for you: use the features already in Codex, or build your own interface with Codex underneath.

**Show / do:** Use the prepared visual. No live typing is required.

**Check:** Ask learners to explain the relationship in their own words.

**Source:** https://learn.chatgpt.com/docs/

## 2. The question behind this lesson
**0.5–1.5 minutes**

The request was for background work that does not require supervising every step. We will use that as the test for both approaches. The target is not a clever answer once. It is a repeatable job that starts when needed, has the right information, and leaves a result you can inspect. Keep those three questions in mind throughout the lesson.

**Show / do:** Point to background work in the quoted request. Ask everyone to think of one job they would like handled while away from their desk.

**Check:** The goal is a repeatable job with a reviewable result.

**Source:** Learner question supplied by Mark; excerpt with omission marked

## 3. Two ways to make your assistant
**1.5–3 minutes**

First use the app you already have. Then see what changes when you build a custom app. The underlying model is only one part of either system. On the left, Codex supplies the screen, chats, tool connections and scheduling controls. On the right, you choose the screen and workflow and connect it to Codex. A custom app is useful when its design solves a problem the existing interface does not.

**Show / do:** Trace the two paths with the pointer. Explain that both can use Codex, but someone has to provide the surrounding features.

**Check:** Learners can name the difference between using an app and building an app.

**Source:** https://learn.chatgpt.com/docs/

## 4. Use Codex itself
**3–3.25 minutes**

Start with the assistant you can use today inside the existing Codex app.

**Show / do:** Use the prepared visual. No live typing is required.

**Check:** Ask learners to explain the relationship in their own words.

**Source:** https://learn.chatgpt.com/docs/

## 5. The native assistant building blocks
**3.25–5.25 minutes**

A useful assistant needs an ongoing job, information and tools, a way to start work, and a way for you to review it. Codex already supplies these building blocks. Follow the diagram around the centre: instructions tell it what the job is; files and tools provide material; a schedule starts the work; phone access lets you steer and review. A missing source cannot be replaced by a more enthusiastic prompt. Start with the fewest connected parts the job needs.

**Show / do:** Walk around all four branches, spending about 20 seconds on the role of each. Return to the centre and explain why the pieces work together.

**Check:** A schedule starts a defined job; it does not define the job for you.

**Source:** https://learn.chatgpt.com/docs/projects
https://learn.chatgpt.com/docs/plugins
https://learn.chatgpt.com/docs/automations
https://learn.chatgpt.com/docs/mobile

## 6. One project, focused conversations
**5.25–6.75 minutes**

Use a project for related files and instructions. Give repeated jobs distinct chats. A project is shared context, not a guarantee that every conversation reads every other transcript. A research conversation and a drafting conversation can use the same project files without becoming the same conversation. Save important conclusions to a file when another job needs them. That gives the next job an explicit source instead of relying on an unseen chat.

**Show / do:** Trace project to research, then project to drafting. Explain where a reusable research summary would be saved.

**Check:** Shared files and chat history are different sources of context.

**Source:** https://learn.chatgpt.com/docs/projects

## 7. Define the job before scheduling it
**6.75–8.25 minutes**

The character can have a name, but its working brief matters. This is a proposed configuration, not a new special file format. Read this as the specification for one assistant. The job names the purpose; sources define what it can know; the result describes what you expect to receive; limits describe where it stops. This small table is more useful than a long personality description.

**Show / do:** Read the four rows once, then show how a research assistant could keep the structure while changing the job and sources.

**Check:** A learner can fill in all four rows for a real recurring task.

**Source:** https://learn.chatgpt.com/docs/automations

## 8. Give the chat a standing job
**8.25–9.75 minutes**

This is a setup request learners can adapt. Keep one small job and review the first result. You do not need three assistants before one works. Break the request into job, sources, output style and action boundary. You can change the job and length without removing source links or the review step. The first manual answer tells you whether the brief is specific enough.

**Show / do:** Point to each part of the exact prompt. Explain one edit you would make for a research job: replace the general project job with a named research question.

**Check:** The first response should use the named material and make missing information visible.

```text
Help me run this project as my personal assistant. Use the files and tools I name. Keep replies short, link to your sources, and tell me what is missing. Draft messages for my review. Ask before sending anything or changing information in another app.
```

**Source:** https://learn.chatgpt.com/docs/projects
https://learn.chatgpt.com/docs/plugins

## 9. Plugins provide the connections
**9.75–11 minutes**

A plugin gives the assistant a supported way to work with another service. Install the one you need and connect the correct account. A model does not gain account access because you mention an app name. The connection belongs to an account and a set of allowed tools. A connected service may support reading, writing or both. Test one small read before a recurring job depends on it. Desktop availability and remote availability also need to match the place the job runs.

**Show / do:** Show the actual Plugins entry. Describe selecting the needed service, checking its account, then testing one small request. Do not connect a live account during this prepared lesson.

**Check:** The assistant can actually retrieve a named source from the intended account.

**Source:** https://learn.chatgpt.com/docs/plugins

## 10. A prompt becomes a scheduled job
**11–13 minutes**

Try the request manually first. When it works, add a schedule and choose where the result returns. After the first scheduled run, inspect the result. A saved schedule is not evidence that the job completed. The sequence is manual result, schedule configuration, completed result. Each step answers a different question: can the job work, when should it start, and did the unattended run work? Save the instruction only after the manual result is useful.

**Show / do:** Trace the arrows. Pause at the third box and distinguish a saved configuration from a completed run.

**Check:** A completed result is the evidence that the background job ran.

**Source:** https://learn.chatgpt.com/docs/automations

## 11. Schedule the job in this chat
**13–14.5 minutes**

This template uses the existing conversation. The time zone is explicit. It deliberately reports what changed rather than repeating all information each morning. Change the time and the project material to suit the job. Keep the time zone and destination explicit. A useful recurring brief reports what changed and what needs attention, rather than reproducing everything it can find.

**Show / do:** Read the time zone, return-to-this-chat wording, and expected result. Describe inspecting the generated schedule before relying on it.

**Check:** The schedule has the intended time, destination and first usable result.

```text
Every weekday at 8:30 AM, America/Toronto, return to this chat. Review the project updates available to you and give me a short brief: what changed, what needs my attention, and what you need from me. Link to sources. If nothing needs attention, say so briefly. Do not send messages or change other apps.
```

**Source:** https://learn.chatgpt.com/docs/automations

## 12. Choose where scheduled results appear
**14.5–16 minutes**

Use the same chat when previous context matters; use an independent run when each result should stand alone. Both can run in the background. Inspect Scheduled to manage runs. Choose the same chat for an ongoing conversation you plan to steer. Choose a fresh run when every report should begin independently. Neither choice gives access to files or services missing from that execution environment.

**Show / do:** Compare the first two table rows with one example: an ongoing project conversation versus a separate weekly report. Point to Scheduled for later inspection.

**Check:** The learner knows where the next result will appear.

**Source:** https://learn.chatgpt.com/docs/automations

## 13. Your phone can steer your computer
**16–17.5 minutes**

The phone is the remote control. Work runs on the connected computer or in Cloud. Start, guide, approve and review from your phone. This is how the native app can feel like a personal assistant on the go. The diagram is a mental model, not an app screenshot. The phone carries your request to the working environment and brings the result back. A long task can continue while you are away; if it needs a decision, you can respond from the phone.

**Show / do:** Trace request from phone to computer and result back. Explain that the tools and files remain at the execution location.

**Check:** Phone access is a control surface, not a new copy of all your desktop tools.

**Source:** https://learn.chatgpt.com/docs/mobile
https://learn.chatgpt.com/docs/remote-connections

## 14. Connect your phone to Codex
**17.5–19.5 minutes**

These are the documented setup labels. Start at the computer, scan the QR code and use the same account and workspace. Availability depends on the app rollout and workspace settings. We are not creating a pairing in this prepared lesson. The phone and computer must be paired through the supported flow. A nearby phone alone is not sufficient. After setup, test a small read from the intended project before trusting a larger job. This lesson provides the documented route; a learner still needs to complete it on their own devices.

**Show / do:** Walk left to right through the visible steps. Call out the same account and host choice. Describe a harmless first test, such as listing files in the intended project.

**Check:** The phone reaches the intended host and project.

**Source:** https://learn.chatgpt.com/docs/mobile
https://learn.chatgpt.com/docs/remote-connections

## 15. What you can ask from your phone
**19.5–21 minutes**

A phone request is still a normal request. Keep it specific. You can also respond to a question or approve a requested action without returning to your desk. The first prompt is a review request; the second continues work. They sound like ordinary messages because the project and conversation already establish the context. When context is ambiguous, name the project or file explicitly.

**Show / do:** Compare the two prompts. Explain that an approval request from an existing task can also be handled from the phone.

**Check:** The request identifies the work without requiring terminal commands.

**Source:** https://learn.chatgpt.com/docs/mobile
https://learn.chatgpt.com/docs/remote-connections

## 16. Where the work actually runs
**21–23 minutes**

Remote access reaches the host and its existing environment. The phone is not suddenly running the Mac tools. If the host sleeps or goes offline, the remote path is unavailable. Cloud work uses the sources and tools available in Cloud. A powered-off laptop cannot execute local work. A cloud task is a separate environment with the sources made available there. Decide the execution route before you promise an always-available assistant. Remote control and cloud execution solve different parts of the problem.

**Show / do:** Read each row as a dependency check. Use the sleeping-laptop example to make the distinction concrete.

**Check:** The learner can identify what must be awake, online or connected.

**Source:** https://learn.chatgpt.com/docs/mobile
https://learn.chatgpt.com/docs/remote-connections

## 17. Native assistant or custom app?
**23–24.5 minutes**

Most people should first try the built-in app. Building becomes useful when you want a very different interface or repeated workflow. Gratis is our concrete example of that second path. The custom path buys control over interaction and workflow, but brings responsibility for all the missing pieces. If the native screen already does the job, begin there. The next section shows the custom path because Gratis is a real example of where that extra work can be worthwhile.

**Show / do:** Recap native setup in one sentence. Use the paired pictures to introduce interface choice as the reason to build.

**Check:** A custom app has a reason beyond merely renaming the assistant.

**Source:** https://learn.chatgpt.com/docs/

## 18. Build your own assistant
**24.5–24.75 minutes**

Now we separate the reusable engine from the app around it.

**Show / do:** Use the prepared visual. No live typing is required.

**Check:** Ask learners to explain the relationship in their own words.

**Source:** https://learn.chatgpt.com/docs/

## 19. An SDK is a ready-made developer kit
**24.75–26.75 minutes**

SDK stands for software development kit. It is a collection of code your app can use. The Codex SDK lets your app ask Codex to work, continue a conversation, and receive the result. You are not training a model. Think of the kit as a reusable connection your program can call. Without it, the developer would do more of the connection work themselves. With it, they can focus on the application. The connector is real code; the picture is a simplified explanation of its role.

**Show / do:** Point to your app, the connector, and Codex in that order, then reverse the path for the result.

**Check:** The SDK connects software to Codex; it is neither a new model nor a finished personal assistant.

**Source:** https://learn.chatgpt.com/docs/codex-sdk

## 20. API, SDK, and app server
**26.75–28.75 minutes**

An API is the agreed way programs talk. An SDK is ready-made code for using a service. Codex app server exposes richer pieces for clients that need chat history, approvals and live events. They are related, not interchangeable product names. An API describes how software can request something. An SDK provides convenient code for making those requests. Codex app server offers a richer conversation interface for clients that need things such as approval events and authentication flows. The right choice follows what you are building.

**Show / do:** Use one sentence per row. Avoid teaching transport protocols or asking anyone to write code.

**Check:** Learners can explain the names without confusing them with models or subscription plans.

**Source:** https://learn.chatgpt.com/docs/codex-sdk
https://learn.chatgpt.com/docs/app-server

## 21. Your app keeps the interface
**28.75–30.25 minutes**

The user types into your interface. Your local backend calls the SDK, which controls Codex. Responses come back and your interface displays them. The SDK is not the visible chat window. The backend is the part of your app doing work behind the screen. It can keep the Codex connection away from browser code, receive progress, and pass displayable results to the interface. The user can still see a friendly chat with no technical commands.

**Show / do:** Trace all four boxes. Name backend as the behind-the-scenes part of the app, then trace the response backwards.

**Check:** The interface and the Codex execution are separate pieces.

**Source:** https://learn.chatgpt.com/docs/codex-sdk

## 22. Using a Codex subscription
**30.25–32.25 minutes**

The supported Codex client can sign in with ChatGPT. That is different from calling the general OpenAI API with a Platform key. The entitlement and limits follow the sign-in path. Each person uses their own eligible account; do not build a public proxy around your personal login. An SDK package itself is not a new subscription. What matters is how the Codex client authenticates. The demonstrated app used ChatGPT sign-in; a Platform API key follows separate API billing. Connected paid services can still charge independently.

**Show / do:** Read the two authentication routes before the third-party-services row. State clearly which route the recorded demo used.

**Check:** No one leaves believing that a ChatGPT subscription includes every OpenAI API call or outside service.

**Source:** https://learn.chatgpt.com/docs/auth
https://learn.chatgpt.com/docs/app-server#authentication-modes

## 23. Gratis: a real custom assistant app
**32.25–33.75 minutes**

Gratis is Mark’s app. The installed build includes the Codex SDK. It has its own bots, conversations, memory, schedules and phone connection. This screenshot is a synthetic example from the app’s source, not Mark’s private history. Look at the custom conversation list and the central chat. Those are Gratis design decisions. The same app can support provider choices behind its interface. We verified its Codex integration in the installed package; this image is used to teach the interface, not prove which provider generated a particular message.

**Show / do:** Show the overall workspace first. Point to the assistant list and the chat area. Keep the walkthrough brief and move to the setup screen.

**Check:** This is Mark’s actual app and its own interface, not a reskinned screenshot claimed to be native Codex.

**Source:** Local installed Gratis 0.23.0: package.json, src/codex-backend.mjs, src/codex-client.mjs; public source https://github.com/earlyaidopters/gratis-community

## 24. Give an assistant its own identity
**33.75–35.25 minutes**

This is an AI-recreated illustration of the Gratis create-bot controls, rearranged into a wide layout for teaching. A name and avatar help people recognize the assistant. They do not create its behavior; the instructions, model and tools do. The actual app may place these controls differently.

**Show / do:** Point out the name, avatar choices and colour swatches. Show how these identify the assistant, then move to the next slide for the working parts.

**Check:** Identity and behavior are separate configuration choices.

**Source:** AI-generated landscape illustration based on the Gratis create-bot reference; not a screenshot. Original reference: gratis-community-create-bot.png.

## 25. What an assistant is made of
**35.25–36.75 minutes**

This is the plain-language skeleton of a bot. The software enforces tool access; an avatar or a prompt cannot grant it. A name and image make it recognizable. Instructions define the task. Model and tool choices determine available capabilities. History and saved memory provide continuity. A schedule decides when the app starts the work. Some controls belong to the app rather than the prompt.

**Show / do:** Walk down the five rows. Use one assistant throughout rather than inventing five examples.

**Check:** An avatar is one small part of a working assistant.

**Source:** Local installed Gratis 0.23.0: package.json, src/codex-backend.mjs, src/codex-client.mjs; public source https://github.com/earlyaidopters/gratis-community

## 26. What Gratis adds around Codex
**36.75–38.75 minutes**

The installed app constructs a Codex SDK client, starts or resumes a thread, and reads streamed events. Gratis supplies its own interface, memory, scheduler and tool bridge. Those capabilities did not appear merely by installing the SDK. The SDK connection in the middle performs agent work. The surrounding app still owns its chat experience, saved information, timing and connections. This is the architectural reason a custom assistant can feel different while using the same Codex engine.

**Show / do:** Point to each outer box before returning to the centre. Explain that these boxes are responsibilities, not separate intelligence models.

**Check:** The SDK does not automatically bring every native Codex app feature into a new application.

**Source:** Local installed Gratis 0.23.0: package.json, src/codex-backend.mjs, src/codex-client.mjs; public source https://github.com/earlyaidopters/gratis-community

## 27. The small piece that calls Codex
**38.75–40.25 minutes**

This is the key idea, not a coding exercise. A few lines start a conversation and request work. Production apps also handle failures, stop controls, storage and permissions. The example on the next slide actually ran through the SDK. You do not need to memorize the syntax. Follow the four actions on the right. Create the connection, start a conversation, request work, then display the result. The last line uses a display helper to explain the idea; the learner kit contains the actual working server and interface.

**Show / do:** Reveal the meaning of each line from top to bottom. Do not type or run these four lines as a complete standalone program.

**Check:** A non-developer can explain the four-step flow.

**Source:** https://learn.chatgpt.com/docs/codex-sdk

## 28. A tiny app using the real SDK
**40.25–42 minutes**

This small teaching app calls the installed Codex client through the SDK. The response is from a real run using ChatGPT sign-in. It is deliberately small so the connection is easy to see. The request intentionally contains two states: writing is done, approval is waiting. The actual answer kept that distinction. That is a better test than receiving a generic hello, because there is something concrete to inspect. The local example also includes a Stop control.

**Show / do:** Read the short request and answer. Point to Ask my assistant and Stop. This screenshot is sufficient if the live local server is not running.

**Check:** The visible answer was produced through an actual SDK call and preserves the pending approval.

**Source:** Recorded local SDK demonstration; production/sdk-demo/test-receipt.json

## 29. The same conversation can continue
**42–43 minutes**

The second request refers to the first result. The backend reused the same thread, so the answer kept Maya and the pending approval. Starting a new thread would need that context again. The follow-up does not repeat the name or the situation. Keeping the same thread lets the app refer back to the prior exchange. It is still the developer’s job to retain or resume the appropriate conversation when the app restarts.

**Show / do:** Read only the new request and answer. Compare with the previous slide and explain what context was carried forward.

**Check:** The second request continued the first conversation; durable restart storage is a separate feature.

**Source:** Recorded local SDK demonstration; production/sdk-demo/test-receipt.json

## 30. Choose the integration for the job
**43–44.5 minutes**

The SDK is a good starting point for embedding Codex tasks. App server is the documented choice for a rich client with authentication, approvals and detailed events. Neither is permission to skip user controls. The simplest useful integration is preferable to the richest one. A local task runner needs less client machinery than a full chat product with authentication and approvals. Someone who only wants a recurring assistant may need no custom code at all.

**Show / do:** Walk down the three use cases. Connect each choice to its goal rather than describing one as universally better.

**Check:** The integration choice follows the application’s needs.

**Source:** https://learn.chatgpt.com/docs/codex-sdk
https://learn.chatgpt.com/docs/app-server

## 31. A prompt to build your first version
**44.5–46.5 minutes**

This is a build brief, not a claim that one prompt completes a production app. Start with the narrowest useful local version and prove the engine connection before adding tools, memory or schedules. Read this as a staged brief: start local, keep the engine connection behind the interface, prove a real answer and follow-up, then add capabilities. Saved conversations are requested for the next version; the tiny demonstration keeps continuity only while its server is running.

**Show / do:** Annotate the prompt aloud in four parts: interface, Codex connection, proof, and scope. Explain what to inspect before asking for further features.

**Check:** The requested build has a narrow first milestone and a visible acceptance test.

```text
Build me a simple local personal-assistant app using the Codex SDK and my existing Codex sign-in. Give it a chat, a Stop button, and saved conversations. Keep credentials out of the browser. Start with text only. Show me a real response and a follow-up in the same conversation. Ask before adding paid services, account connections, or remote access.
```

**Source:** https://learn.chatgpt.com/docs/codex-sdk
https://learn.chatgpt.com/docs/app-server

## 32. The SDK does not build every feature
**46.5–48 minutes**

The model is not the scheduler, database or permission system. You choose which capabilities to add, how they are stored and what users approve. Gratis is evidence of an app combining these pieces, not a guarantee the SDK supplies them. List what your app must own before asking someone to build it. The SDK can run Codex work; it does not make product decisions about storage, recurring triggers or accounts. Native product features remain native unless the custom application implements an equivalent.

**Show / do:** Use the table to explain why simply installing a package does not produce a full Gratis clone.

**Check:** Each product capability has an owner.

**Source:** https://learn.chatgpt.com/docs/codex-sdk
Local installed Gratis 0.23.0: package.json, src/codex-backend.mjs, src/codex-client.mjs; public source https://github.com/earlyaidopters/gratis-community

## 33. Native Codex and Gratis, side by side
**48–49.5 minutes**

These are alternative interfaces and systems. Native Codex supplies its features. Gratis implements its own equivalents and can use Codex as one backend. The installed Gratis UI was on Claude during inspection; Codex support was verified in the installed code. Choose based on workflow and interface requirements. Both routes can support recurring work, but their schedules and mobile connections are their own implementations. The table compares capabilities, not identical behaviour or shared storage.

**Show / do:** Trace one row across both products. Recap the installed-package verification and avoid attributing the existing Claude chat to Codex.

**Check:** The class understands what is built in and what Gratis implements.

**Source:** https://learn.chatgpt.com/docs/mobile
https://learn.chatgpt.com/docs/automations
Local installed Gratis 0.23.0: package.json, src/codex-backend.mjs, src/codex-client.mjs; public source https://github.com/earlyaidopters/gratis-community

## 34. Design one assistant worth keeping
**49.5–54.5 minutes**

Give learners five minutes. They choose the native path or custom app path, name a useful job, and decide the first result they would inspect. Ask two people to explain why they chose their path. Use the first minute to choose a job. Spend the next two minutes deciding native or custom and naming the actual sources. Use the fourth minute to write the first result you would inspect. In the final minute, compare two answers or explain your own if the room is quiet. No account setup is needed to finish this exercise.

**Show / do:** Run a five-minute design exercise from the four visible rows. In a quiet room, work through a research brief yourself and show why native features are enough for its first version.

**Check:** The answer includes a real job, execution route, sources and a concrete review step.

**Source:** Learner design activity

## 35. Your assistant starts with one useful job
**54.5–55 minutes**

Native Codex is the shortest path to useful background work. The SDK lets you put Codex behind your own experience. Choose the path because of the job, not because a bigger system sounds more impressive.

**Show / do:** Use the prepared visual. No live typing is required.

**Check:** Ask learners to explain the relationship in their own words.

**Source:** https://learn.chatgpt.com/docs/
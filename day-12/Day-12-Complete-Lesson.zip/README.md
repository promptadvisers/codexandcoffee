# Day 12 · Your personal assistant, in Codex and beyond

- Day-12-Personal-Assistant.pptx — current editable slide deck
- Day-12-Personal-Assistant.html — offline viewer, notes and copyable prompts
- Assistant-Desk-Learner-Kit.zip — setup guide, prompts and a working local SDK demo
- RUN-OF-SHOW.md — 55-minute instructor guide

The current lesson replaces the earlier calendar-heavy edition. No private chats or credentials are included. No live schedules or phone pairings were created.

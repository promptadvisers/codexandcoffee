# Your personal assistant: native Codex and a custom app

## Start with native Codex

1. Choose or create a project and add the files your assistant needs.
2. Start a chat for one recurring job. Adapt **prompts/native-job.txt**.
3. Test a manual request before scheduling it.
4. Adapt **prompts/native-schedule.txt**. Inspect its time zone, chat destination and first completed run in Scheduled.
5. For phone access, follow the official remote-connection guide. Start at desktop Settings → Connections → Control this Mac or PC. Pair your own phone and keep the host awake, online and running the app.

Availability and exact labels depend on your app version and workspace. The native setup prompts are templates; no schedules or connections were created for this lesson.

## Understand the custom-app route

The Codex SDK is ready-made code that lets your program start and continue Codex work. The app supplies its own interface, storage, scheduling and integrations. A richer client with authentication and approval flows may use Codex app server.

Gratis is Mark's concrete example. Its installed version includes the Codex SDK, starts or resumes conversations and streams results. The example screenshots use synthetic data from the project documentation. Slide 24 is an AI-recreated landscape illustration of the create-bot controls, not a screenshot. The inspected installed UI was on Claude; Codex support was verified in its packaged code.

## Try the tiny local SDK app

The **sdk-demo** folder contains a working local example. It requires Node.js 18+, npm, an installed Codex client and a valid Codex sign-in. It uses your own account and plan limits. General OpenAI API use is billed separately.

Ask Codex: “Help me run the local SDK demo in this folder. Explain any install or sign-in step before doing it. Keep it on my computer.”

Or, from sdk-demo:

```sh
npm install
codex login
npm start
```

Open http://127.0.0.1:4378. Ask the provided question, then ask a follow-up. The conversation continues while the local server is running. This small teaching prototype does not implement persistent chat storage, schedules, account integrations or remote access. The build prompt describes a next version; those features are not claimed as implemented here.

The app binds to localhost only, keeps the SDK on the server side, and has a Stop button. It uses a read-only local Codex workspace. Do not put credentials in browser code or expose your personal account as a public service. Stop the server with Control-C.

## Your next build

Use **prompts/build-assistant.txt** to ask Codex for your own first version. First prove a real response and a follow-up. Add storage, tools, schedules and phone access only when your job needs them.

## Official references

- [Codex SDK](https://learn.chatgpt.com/docs/codex-sdk)
- [Codex app server](https://learn.chatgpt.com/docs/app-server)
- [Authentication](https://learn.chatgpt.com/docs/auth)
- [Scheduled tasks](https://learn.chatgpt.com/docs/automations)
- [Codex on mobile](https://learn.chatgpt.com/docs/mobile)
- [Remote connections](https://learn.chatgpt.com/docs/remote-connections)

import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const {Codex}=await import(process.env.CODEX_SDK_MODULE?pathToFileURL(process.env.CODEX_SDK_MODULE).href:'@openai/codex-sdk');
const env={...process.env};delete env.OPENAI_API_KEY;delete env.CODEX_API_KEY;
const codex=new Codex({codexPathOverride:process.env.CODEX_PATH||'codex',env,config:{features:{apps:false,plugins:false,skill_search:false},project_doc_max_bytes:0}});
let thread=null,busy=false,controller=null;
const transcript=[];const events=[];
const options={workingDirectory:root,sandboxMode:'read-only',approvalPolicy:'never',skipGitRepoCheck:true,networkAccessEnabled:false,webSearchMode:'disabled',threadSource:'assistant-lesson'};
const server=http.createServer(async(req,res)=>{
 try{
 if(req.method==='GET'&&req.url==='/'){res.setHeader('Content-Type','text/html');return res.end(await fs.readFile(path.join(root,'index.html')));}
 if(req.method==='POST'&&req.url==='/api/stop'){controller?.abort();res.end(JSON.stringify({stopped:true}));return;}
 if(req.method!=='POST'||req.url!=='/api/ask'){res.statusCode=404;return res.end();}
 if(busy){res.statusCode=409;return res.end('One request at a time');}
 let body='';for await(const c of req){body+=c;if(body.length>8000)throw Error('Prompt too long');}
 const {prompt}=JSON.parse(body);if(typeof prompt!=='string'||!prompt.trim())throw Error('Write a request first');
 busy=true;controller=new AbortController();thread??=codex.startThread(options);let text='';
 res.setHeader('Content-Type','application/x-ndjson');transcript.push({role:'user',text:prompt});
 const result=await thread.runStreamed(prompt,{signal:controller.signal});
 for await(const event of result.events){
 events.push(event);
 if(event.type==='turn.failed'||event.type==='error')throw Error(event.error?.message||event.message||'Run failed');
 if(event.type==='item.completed'&&event.item.type==='agent_message'){text=event.item.text;res.write(JSON.stringify({text})+'\n');}
 if(event.type==='turn.completed')res.write(JSON.stringify({done:true})+'\n');
 }
 transcript.push({role:'assistant',text});await fs.writeFile(path.join(root,'recorded-run.json'),JSON.stringify({transcript,events,threadId:thread.id},null,2));res.end();
 }catch(e){res.write(JSON.stringify({error:e.message})+'\n');res.end();}finally{busy=false;controller=null;}
});
server.listen(Number(process.env.PORT||4378),'127.0.0.1',()=>console.log('Assistant demo: http://127.0.0.1:'+(process.env.PORT||4378)));

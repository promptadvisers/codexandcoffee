# Recorded SDK example

First response:

Done: The draft is finished.
Waiting: Maya’s approval.

Follow-up in the same conversation:

The draft is finished and awaiting Maya’s approval.

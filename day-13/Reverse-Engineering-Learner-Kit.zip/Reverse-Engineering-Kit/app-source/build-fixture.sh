#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
mkdir -p 'Practice Surface.app/Contents/MacOS'
xcrun swiftc -swift-version 5 Sources/PracticeSurface.swift -o 'Practice Surface.app/Contents/MacOS/PracticeSurface' -framework AppKit
cat > 'Practice Surface.app/Contents/Info.plist' <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>CFBundleIdentifier</key><string>local.day13.practice-surface</string><key>CFBundleName</key><string>Practice Surface</string><key>CFBundleExecutable</key><string>PracticeSurface</string><key>CFBundlePackageType</key><string>APPL</string><key>CFBundleShortVersionString</key><string>1.0</string><key>NSHighResolutionCapable</key><true/></dict></plist>
PLIST
codesign --force --sign - 'Practice Surface.app'

#!/bin/zsh
set -euo pipefail
cd "${0:A:h}"
mkdir -p StageInk.app/Contents/MacOS
xcrun swiftc -swift-version 5 Sources/StageInk.swift -o StageInk.app/Contents/MacOS/StageInk -framework AppKit -framework Carbon
cat > StageInk.app/Contents/Info.plist <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>CFBundleIdentifier</key><string>local.day13.stageink</string><key>CFBundleName</key><string>StageInk</string><key>CFBundleExecutable</key><string>StageInk</string><key>CFBundlePackageType</key><string>APPL</string><key>CFBundleShortVersionString</key><string>1.0</string><key>NSHighResolutionCapable</key><true/><key>LSMinimumSystemVersion</key><string>13.0</string></dict></plist>
PLIST
codesign --force --sign - StageInk.app

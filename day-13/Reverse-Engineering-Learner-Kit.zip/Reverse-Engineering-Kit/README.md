# Reverse engineering an app with Codex

## Follow the lesson

1. Choose one application you can inspect and one behavior you want to understand.
2. Use **prompts/inspect.txt** to collect the visible screens, controls and states.
3. Use **prompts/behavior.txt** to turn a short interaction into a repeatable check.
4. Use **prompts/plan.txt** to write a plan from the observations.
5. Use **prompts/build.txt** to build in stages, then **prompts/verify.txt** to compare the results.
6. Use **prompts/fix.txt** for a reproduced mismatch. The extension prompt is an optional next experiment.

The prompts are readable teaching requests grounded in this exercise. The saved plan, build and verification prompts were sent to the actual exercise chat. The observation request uses teaching-friendly wording; exercise-prompts contains the saved requests from the exercise. See OBSERVED-RESULTS.md for the exact coverage and remaining limits.

## The Mac exercise

StageInk is an independent Mac application built from the observed feature specification. Its source is in app-source. Open that folder in Codex and ask it to read the build script, build the app for your Mac and run it. Apple command-line developer tools are required for the Swift build.

The observed inventory and state map are in evidence. The final test report records the completed checks. The app source includes a script for repeating the 20 component checks.

The plan describes the design decisions and planned checks. Read OBSERVED-RESULTS.md for what was actually demonstrated. Keep design intent separate from a completed test. The Mac build does not establish Windows compatibility.

## Inspection tools

Computer Use lets Codex inspect a visible application and operate its controls. App access depends on your installation and permissions.

REA connects agents to package inspection, code-analysis providers and runtime tools. To prepare it, ask Codex to review the official installation instructions, show the proposed setup, install the parts you select and verify them. Native-code decompilation additionally needs a supported provider such as Hopper, Ghidra, IDA or Kuna.

In this lesson, REA's basic metadata and native framework inspections ran successfully. The deeper native-code request reported missing analysis providers. No internal DemoPro function was decompiled during this exercise.

## Sources

- https://github.com/morluto/rea
- https://rea.tools/
- https://www.demoproapp.com/faq.html
- https://learn.chatgpt.com/docs/computer-use
- https://learn.chatgpt.com/docs/prompting

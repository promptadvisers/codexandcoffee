# Saved staged prompts

- 00-original-request.txt preserves the delegated scope
- 01-inspection-prompt.txt is the focused inspection instruction acted on
- 03-plan-prompt.txt preserves the supplied planning request exactly; BUILD-PLAN.md was saved before source creation
- 04-build-prompt.txt preserves the supplied build request exactly. It arrived after the initial scaffold compile. Subsequent feature gates and retained snapshots followed its staged activation and verification direction
- 05-verification-prompt.txt records the focused verification instruction acted on

Actual build logs, source checkpoints, screenshots and native state trees show the resulting work. The separate lesson-preparation chat supplies the live onscreen chat history. This file does not fabricate replayed turns.

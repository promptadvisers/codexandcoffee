# Day 13 reverse-engineering exercise completion

## Deliverables

- Runnable native app at `StageInk-local-package.zip → StageInk.app`
- Editable Swift at `app-source/Sources/StageInk.swift`
- Build with `app-source/build.sh`; run focused checks with `app-source/check-components.sh`
- Harmless test app at `StageInk-local-package.zip → Practice Surface.app`
- Original screenshots and native control trees in `evidence/`
- Observation inventory, state map, test results and evidence ledger in `evidence/`
- Exact staged prompts in this folder; plan in `BUILD-PLAN.md`
- Runnable stage snapshots and their source in `StageInk-local-package.zip → checkpoints/stage-*`
- Local bundle in `StageInk-local-package.zip`

## What is verified

DemoPro 4.1 build 18 was inventoried in its native settings and menus. Its timer ran, paused and reset. Temporarily changed drawing-toolbar/hotkey-mode/timer settings were restored.

StageInk launches, changes drawing mode, selects tools/colors/width and boards, opens the harmless fixture, and runs the timer through completion. The fixture counter and text field were operated after selecting Desktop/Interact. Saved control values survived a relaunch. All 20 production component checks passed, including five drawing types, reverse drags, undo, clear, independent board data and save/reload.

## What remains unverified

A successful physical desktop stroke and physical click-through transition were not established through Computer Use. Coordinate canvas input returned `noWindowsAvailable` or `windowNotFoundAtPosition`, including fresh app acquisition and the opaque standard-window test. These are recorded as CUA targeting failures, without treating handler tests as end-to-end passes. Global shortcut delivery, multi-display drawing, full-screen presentations and cross-Mac distribution remain unverified.

The final app is left in Desktop / Interact. No publication, global package installation or personal-data edits were performed.

## Teaching images

- Original settings `evidence/screenshots/01-demopro-annotations.png`
- Original timer `evidence/screenshots/21-demopro-timer-running.png`
- Rebuild timer at the matching ten-minute countdown `evidence/screenshots/31-stageink-ten-minute-comparison.png` (09:58)
- Final controls `evidence/screenshots/33-stageink-final-palette.png`
- Timer completion `evidence/screenshots/30-stage4-timer-complete.png`
- Actual production rendering from direct handler tests `StageInk-local-package.zip → component-checks/production-canvas-component-render.png`; label it “component render”

## Staging disclosure

The first compilation contained the core code scaffold. Feature-stage gates exposed pen/mode, then shapes/colors/undo/clear, then boards, then timer. Snapshots preserve those runnable feature sets and exact source. They should be described as staged activation and verification, rather than four independent rewrites. A separate original/rebuild drawing screenshot comparison could not be obtained; the timer comparison uses actual windows from both apps.

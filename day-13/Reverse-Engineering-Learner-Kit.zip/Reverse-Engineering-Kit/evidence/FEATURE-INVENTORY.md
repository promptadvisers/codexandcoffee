# DemoPro 4.1 observed feature inventory

Inspected through Computer Use on 11 November 2026. Installed bundle metadata reports version 4.1, build 18, identifier com.anatole.DemoPro. About window independently displays Version 4.1. No DemoPro binary implementation or assets were copied.

## Evidence labels

- **Visible** means the control, value or explanatory text was read in the native interface
- **Observed action** means the control was operated and the resulting state was captured
- **Unverified** means the interface describes the behavior but a successful live outcome was not established

## Annotations

- Drawing Toolbar switch initially off. It was temporarily enabled and restored off
- Hotkey Mode initially Press & Hold. Its explanatory text says to hold a tool hotkey to draw and release to exit. Menu also offers Toggle. Toggle says to press a tool hotkey to start and press it again or Clear to exit. Toggle was selected for an attempted runtime test and restored to Press & Hold
- Auto Erase initially Off. Choices are Off, After Delay and When Drawing Ends. Alternative timing behavior was not exercised
- Stroke width initially 8. Text size initially 36. Both have number fields and steppers
- Five color rows with individual shortcuts. Blue ⌘E, magenta ⌃P, orange ⌃O, yellow ⌃Y, green ⌃G. Orange was selected throughout
- Initial screenshot shows #0067FF, #FF00C2, #FF5400, #FFEA00, #00DD31. Later settings on the other display show #006EFF, #FF00C8, #FF6E00, #FFEE00, #66DE42. No color editor was operated. The cause of the display-dependent values was not established
- Text has no assigned shortcut in this installation
- Freehand ⌃Z, Line ⌃1, Arrow ⌃Q, Rectangle ⌃A, Ellipse ⌃E, Eraser ⌃D, Undo ⌃U, Clear ⌃X, Whiteboard ⌃W, Blackboard ⌃K
- Arrow direction menu offers Tail to Tip, initially selected, and Tip to Tail
- Drawing shortcuts were attempted through the CUA input route over a harmless fixture. They did not establish a drawing state or produce verified marks. Consequently geometry, drawing toolbar runtime, erase, undo and board persistence are unverified in the original app

## Cursor

- Cursor Highlight initially off, shortcut ⌃H
- Style initially Ring. Menu offers Ring, Disc, Laser and Spotlight
- Size shows 100 with slider. Opacity shows 60% with slider
- Color swatch visually magenta
- Visibility initially Always On. Menu also offers Hide When Idle and On Click Only
- Click Animation initially on
- Pointer Size and Zoom link to System Settings. Links were left unopened to avoid changing unrelated system preferences
- Cursor styles and click animations were inventoried through visible settings, without runtime validation

## Break timer

- Initially off, shortcut ⌃T. Duration 0 h and 10 m. Message “Break Time!”
- Countdown Chime initially off. Font Color cyan. Window Color appears translucent dark gray. Show in Menu Bar When Minimized initially on
- Enabling Break Timer opens a separate resizable window with message, 10:00 countdown, Start, Reset, chime control and three window controls
- Start changed to Pause. Elapsed display was observed at 9:58. Pause changed to Resume. Reset returned to 10:00 and Start
- Window close returned the settings switch to off. Timer was reset and closed
- Completion, chime and minimized menu-bar behavior were not tested in DemoPro

## General

- Launch at Login off. Show Dock Icon off
- Drawing Indicator Dot, with alternatives Scaled, Crosshair, Tool, None
- Pen Pressure off. Visible text says it varies freehand stroke width with pressure and requires Apple Pencil via Sidecar or a drawing tablet
- Toolbar on Boards Auto-Hide, with Show and Hide alternatives
- Board Annotations Separate, with Shared alternative. Visible text says boards use their own canvas, saved across sessions
- Restore Defaults was left untouched

## Menus

- DemoPro menu contains About, Settings, Services, Hide, Hide Others, Show All and Quit. Services showed no applicable services
- Settings More menu contains Help, Write a Review, About DemoPro and Quit
- Edit includes standard Undo/Redo, clipboard, selection, Writing Tools, AutoFill, Dictation and Emoji commands. Most were disabled in the observed state
- View shows disabled Enter Full Screen
- Window includes standard close/minimize/zoom/fill/center/move-resize/full-screen tile and arrange commands, mostly disabled in the observed state
- Help contains DemoPro Help. External Help and review destinations were not opened

## Restored preferences

Drawing Toolbar off, Hotkey Mode Press & Hold, Break Timer off. Timer duration/message/chime were unchanged, the countdown was reset to 10:00 before closing. Other settings were inspected by opening menus and selecting their existing value. Screenshots 22–23 verify restoration. Settings tab position is a navigation state and was left on Annotations.

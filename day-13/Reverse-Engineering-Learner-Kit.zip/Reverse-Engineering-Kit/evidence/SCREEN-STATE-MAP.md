# Observed screen and state map

```text
DemoPro menu bar
  ├─ About → version window → close
  ├─ Settings → Annotations / Cursor / Timer / General
  │    ├─ value menus → choose existing value or dismiss
  │    ├─ More → Help / Review / About / Quit
  │    └─ Timer on → timer window
  │          ├─ Start → running, Pause button
  │          ├─ Pause → paused, Resume button
  │          ├─ Reset → 10:00, Start button
  │          └─ close → timer off
  └─ drawing shortcut attempts → no verified drawing state

StageInk
  ├─ Palette → Draw ↔ Interact, selected surface/tool/color/width
  ├─ Close palette → canvas; app menu Show StageInk → palette
  ├─ Surface → Desktop / Whiteboard / Blackboard
  ├─ Practice surface → Desktop + Interact + harmless fixture
  ├─ Timer → Set → Start → Pause → Resume / Reset
  │                   └─ zero → Break complete
  └─ Quit/relaunch → saved controls, Interact startup
```

StageInk canvas coordinate targeting failed through CUA. The palette, timer and fixture were operated through their accessible controls. The separate drawing test window reached the same coordinate-targeting limitation. Production event handlers and paint output were checked in a separately labeled in-process harness.

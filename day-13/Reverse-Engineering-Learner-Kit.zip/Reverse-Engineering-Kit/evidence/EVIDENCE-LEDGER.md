# Evidence ledger

All screenshots below were captured by CUA from the named native app or the fictional practice fixture. Captures are app windows or app regions. The component render is listed separately.

| File | Pixels | SHA-256 |
|---|---:|---|
| screenshots/01-demopro-annotations.png | 400 × 773 | `abdb79b013e6c6f6945dfbbf8f2e622a92e90fa0c4416006b7dc3bdd2fead300` |
| screenshots/02-demopro-hotkey-options.png | 400 × 773 | `83ca1e051c252db952e1b6c9b380f9df8b19f1606c9372f2e78acc7c1fab0a13` |
| screenshots/03-demopro-autoerase-options.png | 400 × 773 | `a28c5aff878e830df120e38734d8605f120fd20a842feac08eb0138720e2374c` |
| screenshots/04-demopro-arrow-options.png | 400 × 773 | `3c5a6c85621699924590bcc39280525c4af88456151a3bd64f21d10230ec408a` |
| screenshots/05-demopro-cursor.png | 400 × 413 | `a6e4ff1ad87e2d51ed06fd2b7134c86dfe5132a167e367eaffba00f8480d4614` |
| screenshots/06-demopro-cursor-styles.png | 400 × 413 | `a964abe6bba4790b4fd978bb959e9982a38ecb475dc66fcd1a19e186f06f66b6` |
| screenshots/07-demopro-visibility.png | 400 × 413 | `abad407316057fdd139fd45540cb9131f42744c9007b019bd4dc06276d92d8d0` |
| screenshots/08-demopro-timer.png | 400 × 344 | `f433324b4b61af6967a92f86c16ba6bfdf8c5d14453503b23a7dd092891899ea` |
| screenshots/09-demopro-general.png | 400 × 411 | `8311ab648d2bd9cf19a4eb7227dd78ad81c423af4fe18906adbd44dcf004cde1` |
| screenshots/10-demopro-indicators.png | 400 × 411 | `2d188f91e2cc0d7f0e04bf020a25ef924562b401e9837c0f47d35171d579e70a` |
| screenshots/11-demopro-board-toolbar.png | 800 × 822 | `5ff96a7434f560cc6ac2bcff64835c5bb79d9118b2819adf382c4dd240ad900b` |
| screenshots/12-demopro-board-canvases.png | 800 × 822 | `8a8d7cfd94a8bd8202a0a8ab6db91e3975a98e6908a06aa0f764053afe7c0eda` |
| screenshots/13-demopro-more.png | 800 × 822 | `cc9630b6087b0af38a10aef703e56c6309b1b0f21707bd77ed0fefbee1984351` |
| screenshots/14-demopro-about.png | 680 × 344 | `acc6b70cb722743a68d6592f85fe7cd8d30778e3a7a692bd0ee42f5b9db43ada` |
| screenshots/19-practice-surface.png | 3456 × 2168 | `6d163051f133593c0d1de8357825cc968e7d488e3b37022d4ab9270e027ef4b4` |
| screenshots/20-demopro-timer-ready.png | 1600 × 800 | `94db2ee28adb0ee7eee51fe5f468dac3858fca2367c1c12510569c546629dd64` |
| screenshots/21-demopro-timer-running.png | 1600 × 800 | `5059b98b4d70906765f0037f6d1ac11c912345c0cd0b51628c39f7c1ae6aa4f9` |
| screenshots/23-demopro-settings-restored.png | 800 × 1546 | `1029b9e57b37d69cc9152a18341d38fb7ea55beda2447b037789359d45ea919d` |
| screenshots/24-stage1-controls.png | 620 × 888 | `ff13e86f906b5821107f25fe1c6caba17db4b7f335e047aec6c461885b8041fe` |
| screenshots/25-stage3-whiteboard-controls.png | 620 × 888 | `c193cf3199f0aa35e357666af4c38e852d3e16a8a45328b1cc2a07fa8a68c8ed` |
| screenshots/26-stage3-blackboard-controls.png | 620 × 888 | `5176725a9489b414c1e068425747126ec562f51fd18fed8b56ed1b3e744543a2` |
| screenshots/27-stage4-timer-ready.png | 440 × 332 | `ec7052af530ea919e4644ec568893fe576b611479f815201b62fdf237c81a329` |
| screenshots/28-stage4-timer-running.png | 440 × 332 | `fa2dc5b027089272200a41d26bde88b5c8c4438274254b809f57a08c11b1276e` |
| screenshots/29-stage4-timer-paused.png | 440 × 332 | `6977691ca9445496a229f5d98ab2c7a2d66fcdaf98c57a688562f24767d2c81c` |
| screenshots/30-stage4-timer-complete.png | 440 × 332 | `d3f076492beca1cd8378de716c5883c2d624e0247f338d40915f859eacf0c9e3` |
| screenshots/31-stageink-ten-minute-comparison.png | 440 × 332 | `5810edf3cf385753c5239bd4e0ed38ec0e90331add7937579df5f619e25cee33` |
| screenshots/32-stageink-fixture-interaction.png | 3456 × 2168 | `967ac7954735b457c6202ac57ccab5f2f5bded317bcb769a51ffb40e63686e6f` |
| screenshots/33-stageink-final-palette.png | 620 × 888 | `949e2c6723ba02c9399e11739e2782955aaf57641cc9fd66574ac49f80436bd5` |

## Supporting records

- Feature inventory identifies visible controls and runtime-tested behavior
- Screen/state map separates confirmed transitions from unverified drawing transitions
- TEST-RESULTS.md records native UI and component scopes
- Native AX trees accompany settings, menus, restored preferences, timer completion, fixture interaction and final palette
- rebuild/checkpoints/ contains sequential compiler logs and retained source/application stages
- rebuild/runtime-events.jsonl records native control actions and shortcut registrations
- rebuild/component-checks/results.json records 20 passing production-component checks
- rebuild/component-checks/production-canvas-component-render.png is a rendered component output, not a desktop screenshot
- PACKAGE-VERIFICATION.txt records code-signature and executable architecture checks

## Screenshot groups

- 01–14 cover original settings menus and About
- 19 covers the first fixture appearance, before its contrast correction
- 20–21 cover the original timer
- 23 verifies restored DemoPro annotation settings
- 24 covers the first StageInk controls
- 25–26 cover StageInk board/control selections
- 27–30 cover the StageInk timer through completion
- 31 matches the original 10-minute timer scenario at 09:58
- 32 covers accessible fixture interaction with StageInk in Interact/Desktop
- 33 covers the final palette

Menu-only files 15–18 and restored timer file 22 are text captures, not missing screenshot numbers.

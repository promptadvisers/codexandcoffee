# Verification results

## Actual native UI observations

| Check | Status | Evidence |
|---|---|---|
| DemoPro version and menus | Pass | 01–18 captures and menu trees |
| DemoPro timer start/countdown/pause/reset | Pass | 20–21 timer captures, native state transcript |
| DemoPro changed preferences restored | Pass | 22–23 restoration captures |
| DemoPro drawing/shape/board runtime | Unverified | CUA shortcut attempts did not establish drawing state |
| StageInk launches as local native app | Pass | 24 and 33 palette captures |
| Explicit Draw / Interact changes | Pass for control/state | Native label changed, runtime log records both |
| Palette tool Arrow, Blue, width 10 | Pass for selection/save | 25–26 captures and State.json |
| Whiteboard / Blackboard selection | Pass for control/state | 25–26 captures |
| Canvas receives physical mouse drags | Blocked in CUA | noWindowsAvailable; windowNotFoundAtPosition |
| Underlying fixture after Practice surface | Pass for accessible controls | 32 shows counter 0→1 and edited text |
| Draw blocks underlying physical clicks; Interact passes them | Unverified end-to-end | Accessible fixture activation does not establish physical hit-testing |
| Native shape rendering, undo and clear with physical drags | Unverified end-to-end | See separately scoped component passes |
| Timer duration/set/start/countdown/pause/reset/completion | Pass | 27–31 captures, zero reached with Break complete |
| Global keyboard shortcuts | Registered, delivery unverified | All 12 RegisterEventHotKey statuses zero; CUA global-key delivery not established |
| Saved controls survive relaunch, startup Interact | Pass | Stage 3→4 relaunch retained Arrow/Blue/10/Blackboard and started Interact |
| Multiple screens | Unverified visually | App created two overlays; no successful per-screen drag |
| Signed app package | Pass | Ad-hoc codesign verification, arm64 executable |

## Component checks

All 20 checks in rebuild/component-checks/results.json passed against production Canvas methods and StageInkDelegate logic. These call the real mouseDown, mouseDragged, mouseUp and painting methods inside a hidden native window. They establish handler/data/render behavior; they do not simulate physical delivery through WindowServer.

Covered five shape types, intermediate pen samples, two-endpoint shape data, reverse rectangle/ellipse drags, color/width snapshots, visible colored pixels, undo, independent board data, single-click mark, board-scoped clear, empty operations, JSON round trip, inactive handler rejection, timer validation/start/pause/completion/reset.

The generated production-canvas-component-render.png is a component render. It is not a screenshot of a successful desktop drawing session.

## Recovered failures and remaining limits

- Initial practice controls inherited dark-mode text on a light surface. The fixture now uses Aqua appearance
- Closing the controls made the canvas current. Fresh app acquisition, a visible drawing indicator, an opaque test window, a standard accessibility role and an accessible canvas group still did not make CUA coordinate drags succeed. The original transparent behavior is retained in the final app
- One accessibility setter compile failed due to a String argument. The typed NSAccessibility.Subrole correction compiled successfully, with the failed log preserved
- Current app implements the requested core, with timer. It does not implement DemoPro text, eraser, cursor effects, pressure, auto-erase, reverse-arrow mode, custom key recording or menu-bar timer minimization
- Final build is arm64 and ad-hoc signed for this Mac. Cross-Mac Gatekeeper distribution and Intel execution were not tested
- Stroke canvases are keyed to display IDs and use logical coordinates. Display removal/reattachment, resolution changes, Spaces and full-screen presentation apps need a human playback check

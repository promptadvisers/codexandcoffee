# StageInk build plan

Saved before application source was written, 11 November 2026.

## Evidence and design choices

DemoPro 4.1 has a transparent drawing layer, freehand, line, arrow, rectangle and ellipse tools, five colors, width control, undo, clear, whiteboard, blackboard and a break timer. Its settings explicitly distinguish Press & Hold and Toggle, and Separate and Shared board annotations. Screenshots 01–14 record the visible controls and current values. Runtime behavior remains to be exercised on a harmless surface.

StageInk is an independent Swift/AppKit implementation with a distinct name and original UI. A persistent floating palette and explicit Draw/Interact button are design choices that make the mode visible during teaching. Global Command–Option shortcuts avoid DemoPro's existing Control shortcuts. These keys and the keyboard-accessible fixture are design choices. StageInk uses one canvas per display and per background mode. Settings and canvas data stay beside the runnable app.

## Screens and states

- Palette. Shows drawing mode, selected tool, color, width, background and stroke count. Contains undo, clear, timer and harmless fixture controls
- Desktop overlay. Clear background, intercepts drags only in Draw mode. Interact mode passes mouse events to windows underneath and retains marks
- Whiteboard and blackboard. Opaque background with their own marks. Return to Desktop to reveal underlying windows
- Break timer. Separate resizable window, duration in seconds, start/pause/reset, visible remaining time and completion message
- Practice Surface. A full-window fictional presentation canvas with a click counter and editable text field. Used to verify event routing without personal content

## Drawing and keyboard controls

- Pen records drag samples with round joins
- Line and arrow follow drag endpoints, with arrowhead at the release end
- Rectangle and ellipse use the drag bounding box, including reverse-direction drags
- Command–Option–D switches Draw/Interact. Escape leaves Draw mode
- Command–Option–P/L/A/R/E select pen/line/arrow/rectangle/ellipse and enable drawing
- Command–Option–Z removes the newest mark from the current canvas
- Command–Option–X clears the current canvas
- Command–Option–0/1/2 select desktop/whiteboard/blackboard
- Command–Option–T opens the timer
- Buttons offer every core action so keyboard registration failures cannot prevent operation

## Saved state

Store selected tool, color, width, background and marks separately for each display/background in State.json beside the app. Save after completed strokes and settings changes. Start in Interact mode on every launch to avoid trapping input. Timer is transient. These storage, launch-mode and timer rules are design choices.

## Staged implementation and checks

1. Build the fixture and a pen overlay. Verify launch, first stroke and a screenshot. Save compilation output
2. Add explicit Draw/Interact and global toggle. Click the fixture counter while interacting, draw over it while drawing, then confirm the count changes only after returning to interaction
3. Add shapes, color, width, undo, clear and boards. Draw each shape in both drag directions. Inspect actual pixels and counts, undo one mark, clear the canvas, switch boards and return
4. Add the timer. Set a short duration, start, observe countdown, pause/resume/reset and completion. Record any untested timing edge cases
5. Package the local .app with editable source and build script. Relaunch, verify saved settings and safe startup mode. Complete UI test ledger with passes, failures and untested coverage

The single-display test result will not establish multi-display behavior. No source code, binary internals or image assets from DemoPro are used.
